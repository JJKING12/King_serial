#ifndef PLOTSETTING_H
#define PLOTSETTING_H

#include <QMainWindow>
#include "api/api.h"
#include "appconfig/appconfig.h"

#include <QMessageBox>
#include <QCloseEvent>

typedef struct {
    QString head;               // 帧头
    QString tail;               // 帧尾
    QString channel_name_split; // 通道名称分隔符
    QString channel_data_split; // 通道数据分隔符
} struct_param_typedef;

namespace Ui {
class plotSetting;
}

class plotSetting : public QMainWindow
{
    Q_OBJECT

public:
    explicit plotSetting(QWidget *parent = nullptr);
    ~plotSetting();

    void closeEvent(QCloseEvent *e);

signals:
    void get_paramData(struct_param_typedef data, bool isOk);

private slots:
    void on_pushButton_confirm_clicked();

    void on_pushButton_cancel_clicked();

    void PlotConfig();

    void on_lineEdit_frame_head_textEdited(const QString &arg1);

    void on_lineEdit_frame_tail_textEdited(const QString &arg1);


private:
    Ui::plotSetting *ui;

    struct_param_typedef plotDat;
};

#endif // PLOTSETTING_H
