#include "king_serial.h"
#include <QApplication>
#include <QFile>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
#if (QT_VERSION >= QT_VERSION_CHECK(5,6,0))
    a.setAttribute(Qt::AA_EnableHighDpiScaling);
#endif
    King_serial w;
    w.show();

    return a.exec();
}
