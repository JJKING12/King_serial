#include "king_serial.h"
#include "ui_king_serial.h"

King_serial::King_serial(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::King_serial)
{
    ui->setupUi(this);
    king_serial_init();
}

King_serial::~King_serial()
{
    if(mySerial.isOpen) {
        serialPort->close();
    }
    if(myNetwork.isOpen) {
        tcpSocket->abort();
        tcpServer->stop();
        udpServer->abort();
        udpSocket->abort();
    }
    delete plotSet;
    delete ui;
}

/* ------------------------------------------------- 标题栏部分 ----------------------------------------------- */
/* ------------------------------------------------- 标题栏部分 ----------------------------------------------- */
/* ------------------------------------------------- 标题栏部分 ----------------------------------------------- */
void King_serial::initTitleBar()
{
    // 隐藏边框 单击任务栏的按钮，任务栏可实现最小化隐藏窗口
    setWindowFlags(Qt::Window|Qt::FramelessWindowHint |
                   Qt::WindowSystemMenuHint|
                   Qt::WindowMinimizeButtonHint|
                   Qt::WindowMaximizeButtonHint);
    // 设置图标
    setButtonImage(ui->pushButton_logo, ":/pic/KTool.png", 50, 31);

    // 窗口显示在屏幕正中间(适应电脑有多个窗口)
    QDesktopWidget *desktop = QApplication::desktop();
    int currentScreenIndex = desktop->screenNumber(this); // 获取当前软件所在屏幕的序号
    QList<QScreen *> screen_list = QGuiApplication::screens();// 获取指定屏幕的 分辨率
    if(currentScreenIndex < screen_list.count()) {
        QRect screen_rect = screen_list[currentScreenIndex]->geometry(); // 获取到软件窗口所在屏幕的 宽 高 尺寸
        if(AppConfig::flag_firstUse) {
            AppConfig::flag_firstUse = false;
            saveConfig();
            move((screen_rect.width() - width()) / 2,  (screen_rect.height()  - height()) / 2); // 移动窗口到居中
        } else {
            move((screen_rect.width() - AppConfig::width) / 2,  (screen_rect.height()  - AppConfig::height) / 2); // 移动窗口到居中
        }
    }

    // 使用无边框窗口工具类设置边沿任意位置缩放
    mHelper = new FramelessHelper(this);
    mHelper->activateOn(this);              // 激活当前窗体
    mHelper->setTitleHeight(50);            // 设置窗体的标题栏高度
    mHelper->setWidgetMovable(true);        // 设置窗体可移动
    mHelper->setWidgetResizable(true);      // 设置窗体可缩放
    this->resize(AppConfig::width, AppConfig::height);
    softVersion = AppConfig::softVersion;
    downloadUrl = AppConfig::downloadUrl;
}

// 使用事件实现保存软件窗体尺寸 下次打开能够自动读取
void King_serial::resizeEvent(QResizeEvent *event)
{
    Q_UNUSED(event);
    saveConfig();
}

// 设置按钮图标
void King_serial::setButtonImage(QPushButton *button, QString image, int w, int h)
{
    QPixmap pixmap(image);
    QPixmap fitpixmap = pixmap.scaled(w, h, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    button->setIcon(QIcon(fitpixmap));
    button->setIconSize(QSize(w, h));
    button->setFlat(true);
    button->setStyleSheet("background-color:transparent; border: 0px"); //消除边框
}

void King_serial::on_pushButton_min_clicked()
{
    showMinimized();
}

void King_serial::on_pushButton_max_clicked()
{
    if (King_serial::isMaximized()) {
        King_serial::showNormal();//还原事件
        ui->pushButton_max->setIcon(QIcon(":/pic/large.png"));
    } else {
        King_serial::showMaximized();//最大化事件
        ui->pushButton_max->setIcon(QIcon(":/pic/large.png"));
    }
}

void King_serial::on_pushButton_close_clicked()
{
    close();
}

void King_serial::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        m_point = event->globalPos() - frameGeometry().topLeft();
    }
}

void King_serial::mouseReleaseEvent(QMouseEvent *event)
{
    Q_UNUSED(event); // Q_UNUSED() 没有实质性的作用,用来避免编译器警告
}

/* ------------------------------------------------- 状态栏部分 ----------------------------------------------- */
/* ------------------------------------------------- 状态栏部分 ----------------------------------------------- */
/* ------------------------------------------------- 状态栏部分 ----------------------------------------------- */
void King_serial::InitStatusBar()
{
    // 设置高度
    statusBar()->setMinimumHeight(25);
    statusBar()->setStyleSheet(QString("QStatusBar::item{border: 1px}")); // 不显示边框
    label_style = new QLabel();
    cBox_style = new QComboBox();
    QFont font("Consolas", 10);
    label_style->setFont(font);
    label_style->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
    label_style->setText("主题选择");
    statusBar()->addPermanentWidget(label_style);

    QStringList themeList;
    themeList <<"White"
            <<"Blue"
            <<"Purple"
            <<"ElegantDark"
            <<"Manjaro"
            <<"Console"
            <<"MacOS" ;
    cBox_style->setFont(font);
    cBox_style->addItems(themeList);
    cBox_style->setCurrentIndex(cBox_style->findText(AppConfig::Theme));
    statusBar()->addPermanentWidget(cBox_style);
    styleChanged();
    connect(cBox_style, SIGNAL(currentIndexChanged(int)), this, SLOT(styleChanged()));
    connect(cBox_style, SIGNAL(currentTextChanged(QString)), this, SLOT(saveConfig()));
}

void King_serial::styleChanged()
{
    QFile file;
    QString paletteColor;
    QPalette palette;
    //加载样式表
    switch (cBox_style->currentIndex()) {
        case theme_flatWhite: {
            file.setFileName(":/qss/flatwhite.css");
            QLinearGradient gradient(0, 0, width(), 0); // 创建线性渐变对象
            gradient.setColorAt(0.0, QColor("#DFE9F3")); // 设置起始颜色
            gradient.setColorAt(1.0, QColor("#FFFFFF")); // 设置结束颜色
            palette.setBrush(QPalette::Background, gradient); // 将渐变对象设置为背景画刷
            qApp->setPalette(palette);
            PlotUIColor = QColor("#FFFFFF");
            if(customPlot != nullptr) customPlot->setBackground(QBrush(PlotUIColor));
            IconUrl = ":/plot/white";
        }break;
        case theme_lightBlue: {
            file.setFileName(":/qss/lightblue.css");
            QLinearGradient gradient(0, 0, 0, height()); // 创建线性渐变对象
            gradient.setColorAt(0.0, QColor("#5D9FFF")); // 设置起始颜色 7DE2FC
            gradient.setColorAt(0.48, QColor("#B8DCFF")); // 设置起始颜色
            gradient.setColorAt(1.0, QColor("#6BBBFF")); // 设置结束颜色 B9B6E5 A9ACB5;
            palette.setBrush(QPalette::Background, gradient); // 将渐变对象设置为背景画刷
            qApp->setPalette(palette);
            PlotUIColor = QColor("#B8DCFF");
            if(customPlot != nullptr) customPlot->setBackground(QBrush(PlotUIColor));
            IconUrl = ":/plot/blue";
        }break;
        case theme_lightPurple: {
            file.setFileName(":/qss/lightpurple.css");
            QLinearGradient gradient(0, 0, width(), 0); // 创建线性渐变对象
            gradient.setColorAt(0.0, QColor("#f6f3ff")); // 设置起始颜色
            gradient.setColorAt(1.0, QColor("#afb4db")); // 设置结束颜色
            palette.setBrush(QPalette::Background, gradient); // 将渐变对象设置为背景画刷
            qApp->setPalette(palette);
            PlotUIColor = QColor("#f6f3ff");
            if(customPlot != nullptr) customPlot->setBackground(QBrush(PlotUIColor));
            IconUrl = ":/plot/purple";
        }break;
        case theme_ElegantDark: {
            file.setFileName(":/qss/ElegantDark.qss");
            QLinearGradient gradient(0, 0, width(), 0); // 创建线性渐变对象
            gradient.setColorAt(0.0, QColor("#868f96")); // 设置起始颜色
            gradient.setColorAt(1.0, QColor("#596164")); // 设置结束颜色
            palette.setBrush(QPalette::Background, gradient); // 将渐变对象设置为背景画刷
            qApp->setPalette(palette);
            PlotUIColor = QColor("#F0F0F0");
            if(customPlot != nullptr) customPlot->setBackground(QBrush(PlotUIColor));
            IconUrl = ":/plot/dark";
        }break;
        case theme_Manjaro:{
            file.setFileName(":/qss/ManjaroMix.qss");
            QLinearGradient gradient(0, 0, 0, height()); // 创建线性渐变对象
            gradient.setColorAt(0.0, QColor("#13547a")); // 设置起始颜色
            gradient.setColorAt(1.0, QColor("#80d0c7")); // 设置结束颜色
            palette.setBrush(QPalette::Background, gradient); // 将渐变对象设置为背景画刷
            qApp->setPalette(palette);
            PlotUIColor = QColor("#d3dae3");
            if(customPlot != nullptr) customPlot->setBackground(QBrush(PlotUIColor));
            IconUrl = ":/plot/manjaro";
        }break;
        case theme_Console: {
            file.setFileName(":/qss/ConsoleStyle.qss");
            QLinearGradient gradient(0, 0, width(), height()); // 创建线性渐变对象
            gradient.setColorAt(0.0, QColor("#3F3F3F")); // 设置起始颜色
            gradient.setColorAt(0.8, QColor("#2B2B2B")); // 设置中间颜色
            gradient.setColorAt(1.0, QColor("#130c0e")); // 设置结束颜色
            palette.setBrush(QPalette::Background, gradient); // 将渐变对象设置为背景画刷
            qApp->setPalette(palette);
            PlotUIColor = QColor("#656565");
            if(customPlot != nullptr) customPlot->setBackground(QBrush(PlotUIColor));
            IconUrl = ":/plot/black";
        }break;
        case theme_MacOS:{
            file.setFileName(":/qss/MacOS.qss");
            qApp->setPalette(QPalette(QColor("#ececec")));
            PlotUIColor = QColor("#f4f4f4");
            if(customPlot != nullptr) customPlot->setBackground(QBrush(PlotUIColor));
            IconUrl = ":/plot/mac";
        }break;
    }
    if (file.open(QFile::ReadOnly)) {
        QString qss = QLatin1String(file.readAll());
        qApp->setStyleSheet(qss);
        file.close();
    }
    if(myPlot.isOpen) ui->pushButton_plot_start->setIcon(QIcon(QString("%1/start.png").arg(IconUrl)));
    else              ui->pushButton_plot_start->setIcon(QIcon(QString("%1/stop.png").arg(IconUrl)));
    if(myPlot.isEnlarge) ui->pushButton_plot_resize->setIcon(QIcon(QString("%1/small.png").arg(IconUrl)));
    else                 ui->pushButton_plot_resize->setIcon(QIcon(QString("%1/large.png").arg(IconUrl)));
    if(myPlot.autoRefresh_Y) ui->pushButton_plot_autoOrHand->setIcon(QIcon(QString("%1/auto.png").arg(IconUrl)));
    else                     ui->pushButton_plot_autoOrHand->setIcon(QIcon(QString("%1/hand.png").arg(IconUrl)));
    ui->pushButton_plot_hideOrShow->setIcon(QIcon(QString("%1/hide.png").arg(IconUrl)));
    ui->pushButton_plot_refresh->setIcon(QIcon(QString("%1/refresh.png").arg(IconUrl)));
    ui->pushButton_plot_save->setIcon(QIcon(QString("%1/save.png").arg(IconUrl)));
}

/* ------------------------------------------------- 通用部分 ----------------------------------------------- */
/* ------------------------------------------------- 通用部分 ----------------------------------------------- */
/* ------------------------------------------------- 通用部分 ----------------------------------------------- */
//! \brief zipReader    zip包解压缩
//! \param zipPath      压缩包路径
//! \param unzipPath    解压缩路径
//! \return 是否解压成功
bool zipReader(QString zipPath, QString unzipPath)
{
    QDir tempDir;
    if(!tempDir.exists(unzipPath))
        tempDir.mkpath(unzipPath);
    QZipReader zipreader(zipPath);
    return zipreader.extractAll(unzipPath);
}

/* -----------------------------------------------
// 如果想使用Qt Creator进行打包，你可以按照以下步骤进行设置：
// 在Qt Creator的项目设置中，进入"Build & Run" -> "Build"选项卡。
// 在"Build Steps"部分，找到"qmake"步骤，并在"Additional arguments（额外的参数）"字段中添加以下参数：
// CONFIG+=openssl
// 点击"OK"保存设置，然后重新构建和打包你的应用程序
// 这样，Qt Creator会自动将OpenSSL库链接到你的应用程序中，并确保在打包后仍然支持它。
// 如需使用 Virtual Box打包应用， 还需要将 libeay32.dll 和 ssleay32.dll 添加到打包目录中
  ----------------------------------------------- */
// 软件检查更新按钮
void King_serial::on_pushButton_check_update_clicked()
{
    // Qt支持SSL 参考博客1：https://blog.csdn.net/gm2418/article/details/129865506
    //          参考博客2：https://blog.csdn.net/u013052326/article/details/111713932
    // 运行下述代码即可诊断是否缺少OPenSSL库
//    qDebug() << "输出当前QT支持的openSSL版本: " << QSslSocket::sslLibraryBuildVersionString();
//    qDebug() << "OpenSSL支持情况: " <<QSslSocket::supportsSsl();
//    qDebug() << "OpenSSL运行时SSL库版本: " << QSslSocket::sslLibraryBuildVersionString();
//     打印输出如下：
//    输出当前QT支持的openSSL版本:  "OpenSSL 1.0.2p  14 Aug 2018"
//    OpenSSL支持情况:  true
//    OpenSSL运行时SSL库版本:  "OpenSSL 1.0.2p  14 Aug 2018"
//    zipReader(QApplication::applicationDirPath()+"/download/King_Tool", QApplication::applicationDirPath()+"/download");
//    return;
    updateFileName = QUrl(UPDATE_URL).fileName();
    json_down = new downloadTool(UPDATE_URL, QApplication::applicationDirPath() + "/download");
    json_down->startDownload();
    connect(json_down, SIGNAL(sigProgress(qint64, qint64, qreal, QString)), this, SLOT(Json_showProgress(qint64, qint64, qreal, QString)));
    connect(json_down, SIGNAL(download_failed()), this, SLOT(Json_downloadFailed()));
    connect(json_down, SIGNAL(download_succeed()), this, SLOT(Json_downloadSucceed()));

    Json_progressDialog = new QProgressDialog("downloading...", "cancel", 0, 100, this);
    Json_progressDialog->setWindowFlags(Qt::Dialog | Qt::CustomizeWindowHint | Qt::WindowTitleHint);//不显示进度条上的“最小化”“最大化”“关闭”
    Json_progressDialog->setWindowTitle(tr("下载进度"));
    Json_progressDialog->setModal(true);// 以模态方式弹出对话框
    Json_progressDialog->showNormal();
    Json_progressDialog->setValue(0);
}

/* ---------------- 解析Json文件的内容 ------------------- */
void King_serial::Json_showProgress(qint64 bytesRead, qint64 totalBytes, qreal progress, QString progressInfo)
{
    Q_UNUSED(bytesRead);
    Q_UNUSED(totalBytes);
    Json_progressDialog->setLabelText(progressInfo);
    Json_progressDialog->setValue(int(progress));
    if (int(progress) > Json_progressDialog->maximum() || Json_progressDialog->wasCanceled()) {
        json_down->cancelDownload();
        Json_progressDialog->close();
    }
}

void King_serial::Json_downloadFailed()
{
    Json_progressDialog->close();
    QMessageBox::warning(this, "警告", "获取网络更新信息失败，请检查网络设置...");
}

void King_serial::Json_downloadSucceed()
{
    Json_progressDialog->close();
    ParseJson(QApplication::applicationDirPath() + "/download", updateFileName);
}

bool King_serial::ParseJson(QString filePath, QString fileName)
{
    QFile file(QString("%1/%2").arg(filePath).arg(fileName));
    if (!file.open(QIODevice::ReadOnly)) return false;

    QJsonParseError jerr;
    QJsonDocument root_Doc = QJsonDocument::fromJson(file.readAll(), &jerr);
    if (root_Doc.isNull()) {
        return false;
    }
    if (root_Doc.isObject()) {
        QJsonObject root_Obj = root_Doc.object();   // 创建JSON对象
        QString curVersion = root_Obj.value("Version").toString(); // 获取最新版本
        QString curUrl = root_Obj.value("url").toString();
        QString UpdateTime = root_Obj.value("date").toString();
        QString description = root_Obj.value("description").toString();

        // 获取的最新版本 大于 当前版本
        if (QString::compare(curVersion, AppConfig::softVersion, Qt::CaseSensitive) > 0) {
            int recv = QMessageBox::warning(this, "Tips", QString("检测到新版本!!!\n\n"
                                                       "版本号：%1\n"
                                                       "更新时间：%2\n"
                                                       "更新说明：\n%3\n"
                                                       "是否进行版本更新?")
                                                       .arg(curVersion)
                                                       .arg(UpdateTime)
                                                       .arg(description),
                                                       QMessageBox::Yes, QMessageBox::No);
            if (recv == QMessageBox::Yes) {
                softVersion = curVersion;
                downloadUrl = curUrl;

                soft_down = new downloadTool(downloadUrl, QApplication::applicationDirPath() + "/download");
                soft_down->startDownload();
                connect(soft_down, SIGNAL(sigProgress(qint64, qint64, qreal, QString)), this, SLOT(Soft_showProgress(qint64, qint64, qreal, QString)));
                connect(soft_down, SIGNAL(download_failed()), this, SLOT(Soft_downloadFailed()));
                connect(soft_down, SIGNAL(download_succeed()), this, SLOT(Soft_downloadSucceed()));

                Soft_progressDialog = new QProgressDialog("downloading...", "cancel", 0, 100, this);
                Soft_progressDialog->setWindowFlags(Qt::Dialog | Qt::CustomizeWindowHint | Qt::WindowTitleHint);//不显示进度条上的“最小化”“最大化”“关闭”
                Soft_progressDialog->setWindowTitle(tr("下载中..."));
                Soft_progressDialog->setModal(true);// 以模态方式弹出对话框
                Soft_progressDialog->showNormal();
                Soft_progressDialog->setValue(0);
            }
        } else {
            QMessageBox::about(this, "Tips", QString("^_^ 当前已是最新版本~~~"));
            return false;
        }
    }
    return false;
}

void King_serial::Soft_showProgress(qint64 bytesRead, qint64 totalBytes, qreal progress, QString progressInfo)
{
    Q_UNUSED(bytesRead);
    Q_UNUSED(totalBytes);
    Soft_progressDialog->setLabelText(progressInfo);
    Soft_progressDialog->setValue(int(progress));
    if (int(progress) > Soft_progressDialog->maximum() || Soft_progressDialog->wasCanceled()) {
        softVersion = AppConfig::softVersion;
        downloadUrl = AppConfig::downloadUrl;
        soft_down->cancelDownload();
        Soft_progressDialog->close();
    }
}

void King_serial::Soft_downloadFailed()
{
    softVersion = AppConfig::softVersion;
    downloadUrl = AppConfig::downloadUrl;
    Soft_progressDialog->close();
    QMessageBox::warning(this, "警告", "软件下载失败");
}

void King_serial::Soft_downloadSucceed()
{
    Soft_progressDialog->close();
    saveConfig();
    int res = QMessageBox::warning(this, "tips", "需要现在打开新版本软件吗?", QMessageBox::Yes | QMessageBox::No);
    if(res == QMessageBox::Yes) {
        bool sta = zipReader(QApplication::applicationDirPath()+"/download/King_Tool.zip", QApplication::applicationDirPath()+"/download");
        if(sta == true) {
            qApp->closeAllWindows();    // 关闭所有窗体，即关闭软件

            // 1.先删除应用程序
            QFile fileTemp1(QApplication::applicationDirPath()+"/King_Tool.exe");
            fileTemp1.remove();
            // 2.再将解压的应用程序移动到根目录
            QFile::rename(QApplication::applicationDirPath()+"/download/King_Tool.exe", QApplication::applicationDirPath()+"/King_Tool.exe"); // A路径移动到B路径
            // 3.最后删除解压后的应用程序 不知道为什么移动后没有删除
            QFile fileTemp2(QApplication::applicationDirPath()+"/download/King_Tool.exe");
            fileTemp2.remove();

            QProcess::startDetached(qApp->applicationFilePath(), QStringList()); // 重启软件，第二个参数可避免路径中有空格
        }
    }
}

void King_serial::king_serial_init()
{
    // 1.时基定时器初始化
    timer_basic = new QTimer();
    timer_basic->setInterval(1000);
    connect(timer_basic, SIGNAL(timeout()), this, SLOT(timer_basic_task()));
    timer_basic->start();
    // 2.发送定时器初始化
    timer_send = new QTimer();
    connect(timer_send, SIGNAL(timeout()), this, SLOT(sendData()));
    // 3.发送按钮信号与槽绑定
    connect(ui->pushButton_send, SIGNAL(clicked()), this, SLOT(sendData()));
    // 4.保存定时器初始化
    timer_save = new QTimer();
    connect(timer_save, SIGNAL(timeout()), this, SLOT(serial_saveData()));
    // 5.读取ini配置文件并完成初始化配置
    AppConfig::readConfig();
    basic_config();
    serial_config();
    plot_config();
    network_config();
    ModBus_config();
    InitStatusBar();
    initTitleBar();
    // 6.默认显示串口页面
    ui->tabWidget->setCurrentIndex(0);
    ui->tabWidget_todo->setCurrentIndex(0);
    ui->label_mailbox->setText(MAILBOX_LINK"1360189633@qq.com");
    ui->label_blog->setText(MYBLOG_LINK"https://blog.csdn.net/");
    // 7.分裂器 - 波形和数据接收
//    ui->splitter_upAndDown->setStretchFactor(0, 1); // 0-up  1-伸缩因子
//    ui->splitter_upAndDown->setStretchFactor(1, 2); // 1-center 2-伸缩因子
//    ui->splitter_upAndDown->setStretchFactor(2, 1); // 2-down 1-伸缩因子
    // 8.分裂器 - 配置和显示
    ui->splitter_leftAndRight->setStretchFactor(0, 0);// 0-left  0-不伸缩
    ui->splitter_leftAndRight->setStretchFactor(1, 2);// 1-right 2-伸缩因子
}

void King_serial::basic_config()
{
    // 1.重写控件内容
    ui->checkBox_hex_send->setChecked(AppConfig::HexSend);
    ui->checkBox_hex_recv->setChecked(AppConfig::HexReceive);
    ui->checkBox_time_stamp->setChecked(AppConfig::TimeStamp);
    ui->checkBox_auto_clear->setChecked(AppConfig::AutoClear);
    ui->checkBox_autoReturn->setChecked(AppConfig::Auto_Return);
    ui->checkBox_topShow->setChecked(AppConfig::TopShow);
    ui->comboBox_auto_send->setCurrentIndex(ui->comboBox_auto_send->findText(QString::number(AppConfig::SendInterval)));
    ui->comboBox_auto_save->setCurrentIndex(ui->comboBox_auto_save->findText(QString::number(AppConfig::SaveInterval)));
    ui->checkBox_auto_send->setChecked(AppConfig::AutoSend);
    ui->checkBox_auto_save->setChecked(AppConfig::AutoSave);
    ui->checkBox_send0->setChecked(AppConfig::CheckSend0);
    ui->checkBox_send1->setChecked(AppConfig::CheckSend1);
    ui->checkBox_send2->setChecked(AppConfig::CheckSend2);
    ui->checkBox_send3->setChecked(AppConfig::CheckSend3);
    ui->checkBox_send4->setChecked(AppConfig::CheckSend4);
    ui->checkBox_send5->setChecked(AppConfig::CheckSend5);
    ui->checkBox_send6->setChecked(AppConfig::CheckSend6);
    ui->checkBox_send7->setChecked(AppConfig::CheckSend7);
    ui->checkBox_send8->setChecked(AppConfig::CheckSend8);
    ui->checkBox_send9->setChecked(AppConfig::CheckSend9);
    ui->lineEdit_send0->setText(AppConfig::TextSend0);
    ui->lineEdit_send1->setText(AppConfig::TextSend1);
    ui->lineEdit_send2->setText(AppConfig::TextSend2);
    ui->lineEdit_send3->setText(AppConfig::TextSend3);
    ui->lineEdit_send4->setText(AppConfig::TextSend4);
    ui->lineEdit_send5->setText(AppConfig::TextSend5);
    ui->lineEdit_send6->setText(AppConfig::TextSend6);
    ui->lineEdit_send7->setText(AppConfig::TextSend7);
    ui->lineEdit_send8->setText(AppConfig::TextSend8);
    ui->lineEdit_send9->setText(AppConfig::TextSend9);

    // 2.连接需要绑定的控件信号与槽 绑定ini文件
    connect(ui->checkBox_hex_send, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));
    connect(ui->checkBox_hex_recv, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));
    connect(ui->checkBox_time_stamp, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));
    connect(ui->checkBox_auto_clear, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));
    connect(ui->checkBox_autoReturn, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));
    connect(ui->checkBox_topShow, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));
    connect(ui->comboBox_auto_send, SIGNAL(currentIndexChanged(int)), this, SLOT(saveConfig()));
    connect(ui->comboBox_auto_save, SIGNAL(currentIndexChanged(int)), this, SLOT(saveConfig()));
    connect(ui->checkBox_auto_send, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));
    connect(ui->checkBox_auto_save, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));
    connect(ui->checkBox_send0, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));
    connect(ui->checkBox_send1, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));
    connect(ui->checkBox_send2, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));
    connect(ui->checkBox_send3, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));
    connect(ui->checkBox_send4, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));
    connect(ui->checkBox_send5, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));
    connect(ui->checkBox_send6, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));
    connect(ui->checkBox_send7, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));
    connect(ui->checkBox_send8, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));
    connect(ui->checkBox_send9, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));
    connect(ui->lineEdit_send0, SIGNAL(textChanged(QString)), this, SLOT(saveConfig()));
    connect(ui->lineEdit_send1, SIGNAL(textChanged(QString)), this, SLOT(saveConfig()));
    connect(ui->lineEdit_send2, SIGNAL(textChanged(QString)), this, SLOT(saveConfig()));
    connect(ui->lineEdit_send3, SIGNAL(textChanged(QString)), this, SLOT(saveConfig()));
    connect(ui->lineEdit_send4, SIGNAL(textChanged(QString)), this, SLOT(saveConfig()));
    connect(ui->lineEdit_send5, SIGNAL(textChanged(QString)), this, SLOT(saveConfig()));
    connect(ui->lineEdit_send6, SIGNAL(textChanged(QString)), this, SLOT(saveConfig()));
    connect(ui->lineEdit_send7, SIGNAL(textChanged(QString)), this, SLOT(saveConfig()));
    connect(ui->lineEdit_send8, SIGNAL(textChanged(QString)), this, SLOT(saveConfig()));
    connect(ui->lineEdit_send9, SIGNAL(textChanged(QString)), this, SLOT(saveConfig()));

    timer_send->setInterval(AppConfig::SendInterval);
    timer_save->setInterval(AppConfig::SaveInterval);
    if (AppConfig::AutoSend) timer_send->start();
    if (AppConfig::AutoSave) timer_save->start();
}

void King_serial::sleep(unsigned long msec)
{
    if (msec <= 0) {
        return;
    }

    #if (QT_VERSION >= QT_VERSION_CHECK(5,0,0))
        QThread::msleep(msec);
    #else
        QTime endTime = QTime::currentTime().addMSecs(msec);
        while (QTime::currentTime() < endTime) {
            QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
        }
    #endif
}

QString King_serial::appPath()
{
    static QString path;
    if (path.isEmpty()) {
#ifdef Q_OS_ANDROID
        //默认安卓根目录
        path = "/storage/emulated/0";
        //带上程序名称作为目录 前面加个0方便排序
        path = path + "/0" + appName();
#else
        path = qApp->applicationDirPath();
#endif
    }
    return path;
}

void King_serial::saveConfig()
{
    AppConfig::softVersion = softVersion;
    AppConfig::downloadUrl = downloadUrl;
    AppConfig::flag_firstUse = false;
    AppConfig::width = width();
    AppConfig::height = height();

    AppConfig::HexSend = ui->checkBox_hex_send->isChecked();
    AppConfig::HexReceive = ui->checkBox_hex_recv->isChecked();
    AppConfig::TimeStamp = ui->checkBox_time_stamp->isChecked();
    AppConfig::AutoClear = ui->checkBox_auto_clear->isChecked();
    AppConfig::Auto_Return = ui->checkBox_autoReturn->isChecked();
    AppConfig::TopShow = ui->checkBox_topShow->isChecked();
    AppConfig::AutoSend = ui->checkBox_auto_send->isChecked();
    AppConfig::AutoSave = ui->checkBox_auto_save->isChecked();
    AppConfig::Theme = cBox_style->currentText();

    int sendInterval = ui->comboBox_auto_send->currentText().toInt();
    if (sendInterval != AppConfig::SendInterval) {
        AppConfig::SendInterval = sendInterval;
        timer_send->setInterval(AppConfig::SendInterval);
    }
    int saveInterval = ui->comboBox_auto_save->currentText().toInt();
    if (saveInterval != AppConfig::SaveInterval) {
        AppConfig::SaveInterval = saveInterval;
        timer_save->setInterval(AppConfig::SaveInterval);
    }

    AppConfig::BaudRate = ui->comboBox_serial_baudrate->currentText().toInt();
    AppConfig::DataBit = ui->comboBox_serial_dataBit->currentText().toInt();
    AppConfig::Parity = ui->comboBox_serial_parityBit->currentText();
    AppConfig::StopBit = ui->comboBox_serial_stopBit->currentText().toDouble();
    AppConfig::FlowControl = ui->comboBox_serial_flow_control->currentText();
    AppConfig::TextSend = ui->textEdit_send->toPlainText();

    AppConfig::NetMode = ui->comboBox_network_mode->currentText();
    AppConfig::NetIP = ui->comboBox_network_ip->currentText();
    AppConfig::NetPort = ui->lineEdit_network_port->text().toInt();
    AppConfig::NetUDPIP = ui->comboBox_network_udpIp->currentText();
    AppConfig::NetUDPPort = ui->lineEdit_network_udpPort->text().toInt();
    AppConfig::NetReConnect = ui->checkBox_network_reconnect->isChecked();
    AppConfig::NetSendAll = ui->checkBox_network_sendToAnyone->isChecked();

    AppConfig::PlotObserveNum = ui->spinBox_xPoints->value();
    customPlot->xAxis->setRange(int(myPlot.x_point_cnt)-ui->spinBox_xPoints->value(), myPlot.x_point_cnt);
    customPlot->replot(QCustomPlot::rpQueuedReplot);// 更新绘图 rpQueuedReplot:可避免重复绘图

    AppConfig::CheckSend0 = ui->checkBox_send0->isChecked();
    AppConfig::CheckSend1 = ui->checkBox_send1->isChecked();
    AppConfig::CheckSend2 = ui->checkBox_send2->isChecked();
    AppConfig::CheckSend3 = ui->checkBox_send3->isChecked();
    AppConfig::CheckSend4 = ui->checkBox_send4->isChecked();
    AppConfig::CheckSend5 = ui->checkBox_send5->isChecked();
    AppConfig::CheckSend6 = ui->checkBox_send6->isChecked();
    AppConfig::CheckSend7 = ui->checkBox_send7->isChecked();
    AppConfig::CheckSend8 = ui->checkBox_send8->isChecked();
    AppConfig::CheckSend9 = ui->checkBox_send9->isChecked();
    AppConfig::TextSend0  = ui->lineEdit_send0->text();
    AppConfig::TextSend1  = ui->lineEdit_send1->text();
    AppConfig::TextSend2  = ui->lineEdit_send2->text();
    AppConfig::TextSend3  = ui->lineEdit_send3->text();
    AppConfig::TextSend4  = ui->lineEdit_send4->text();
    AppConfig::TextSend5  = ui->lineEdit_send5->text();
    AppConfig::TextSend6  = ui->lineEdit_send6->text();
    AppConfig::TextSend7  = ui->lineEdit_send7->text();
    AppConfig::TextSend8  = ui->lineEdit_send8->text();
    AppConfig::TextSend9  = ui->lineEdit_send9->text();

    AppConfig::ModBusProtocol = ui->comboBox_modBus_mode->currentText();
    AppConfig::ModBusReadFormat = ui->comboBox_modBus_readFormat->currentText();
    AppConfig::ModBusByteEndian = ui->comboBox_modBus_byteEndian->currentText();
    AppConfig::ModBusSlaveAddr = ui->lineEdit_modBus_slaveAddr->text();
    AppConfig::ModBusFuncCode = ui->lineEdit_modBus_funcCode->text();
    AppConfig::ModBusReadAddr = ui->lineEdit_modBus_readAddr->text();
    AppConfig::ModBusReadLen = ui->lineEdit_modBus_readLength->text();

    AppConfig::writeConfig();
}

void King_serial::sendInfo(int type, const QString &data, bool clear)
{
    static int currentCount = 0;
    static int maxCount = 2000;

    if (clear) {
        ui->textBrowser_recv->clear();
        currentCount = 0;
        return;
    }
    if (currentCount >= maxCount) {
        ui->textBrowser_recv->clear();
        currentCount = 0;
    }
    if(!mySerial.isShow) {
        return;
    }
    // 过滤回车换行符
    QString strData = data;
    strData = strData.replace("\r", "");
    strData = strData.replace("\n", "");

    // 不同类型不同颜色显示
    QString strType;
    if (type == msgType_serial_send) {
        strType = "串口发送 >>";
        ui->textBrowser_recv->setTextColor(QColor(0, 113, 193));
    } else if (type == msgType_serial_recv) {
        strType = "串口接收 <<";
        ui->textBrowser_recv->setTextColor(QColor(214, 77, 84));
    } else if (type == msgType_network_send) {
        strType = "网络发送 >>";
        ui->textBrowser_recv->setTextColor(QColor(162, 121, 197));
    } else if (type == msgType_network_recv) {
        strType = "网络接收 <<";
        ui->textBrowser_recv->setTextColor(QColor(100, 184, 255));
    } else if (type == msgType_modbus_send) {
        strType = "ModBus发送 >>";
        ui->textBrowser_recv->setTextColor(QColor(72, 103, 149));
    } else if (type == msgType_modbus_recv) {
        strType = "ModBus接收 <<";
        ui->textBrowser_recv->setTextColor(QColor(0, 177, 125));
    } else if (type == msgType_about) {
        strType = "提示信息 >>";
        ui->textBrowser_recv->setTextColor(QColor(250, 170, 20));
    } else if(type == msgType_error) {
        strType = "错误类型 >>";
        ui->textBrowser_recv->setTextColor(QColor(185, 87, 86));
    }

    if(ui->checkBox_time_stamp->isChecked()) {
        strData = QString("[%1] %2 %3").arg(CURR_TIME).arg(strType).arg(strData);
    }

    ui->textBrowser_recv->append(strData);
    currentCount ++;
}

void King_serial::sendBuff(QString data)
{
    QByteArray buffer;
    if (ui->checkBox_hex_send->isChecked()) {
        if(api::isIllegalHex(data.remove(" ").toStdString())) {
            QMessageBox::warning(this, "Warning", "字符串包含非16进制字符，无法转换!");
            return;
        }
        buffer = QByteArray::fromHex(data.toLocal8Bit());
    } else {
        buffer = data.toLocal8Bit();
    }
    if(ui->checkBox_autoReturn->isChecked()) {
        buffer.append("\r\n");
    }
    if(mySerial.isOpen) {
        serialPort->write(buffer);
        if(myModBus.isOpen) {
            sendInfo(msgType_modbus_send, data, false);
        } else {
            sendInfo(msgType_serial_send, data, false);
        }
        mySerial.sendCount = mySerial.sendCount + buffer.size();
        ui->pushButton_sendCount->setText(QString("发送: %1 字节").arg(mySerial.sendCount));
    }
    if(myNetwork.isOpen) {
        switch (myNetwork.mode) {
            case NetMode_TcpServer: {
                if (ui->checkBox_network_sendToAnyone->isChecked()) {
                    tcpServer->writeData(buffer);
                } else {
                    int row = ui->listWidget_network_clientList->currentRow();
                    if (row >= 0) {
                        QStringList list = ui->listWidget_network_clientList->item(row)->text().split(":");
                        tcpServer->writeData(list.at(0), list.at(1).toInt(), buffer);
                    }
                }
            }break;

            case NetMode_TcpSocket: {
                tcpSocket->write(buffer);
                sendInfo(msgType_network_send, data, false);
            }break;

            case NetMode_UdpServer: {
                if (ui->checkBox_network_sendToAnyone->isChecked()) {
                    for (int i = 0; i < ui->listWidget_network_clientList->count(); i++) {
                        QStringList list = ui->listWidget_network_clientList->item(i)->text().split(":");
                        udpServer->writeDatagram(buffer, QHostAddress(list.at(0)), quint16(list.at(1).toInt()));
                        QString buf = QString("[%1:%2] %3").arg(list.at(0)).arg(list.at(1).toInt()).arg(data);
                        sendInfo(msgType_network_send, buf, false);
                    }
                } else {
                    int row = ui->listWidget_network_clientList->currentRow();
                    if (row >= 0) {
                        QStringList list = ui->listWidget_network_clientList->item(row)->text().split(":");
                        udpServer->writeDatagram(buffer, QHostAddress(list.at(0)), quint16(list.at(1).toInt()));
                        QString buf = QString("[%1:%2] %3").arg(list.at(0)).arg(list.at(1).toInt()).arg(data);
                        sendInfo(msgType_network_send, buf, false);
                    }
                }
            }break;

            case NetMode_UdpSocket: {
                QString ip = ui->comboBox_network_udpIp->currentText();
                quint16 port = ui->lineEdit_network_udpPort->text().toUShort();
                // 指定地址和端口发送数据
                udpSocket->writeDatagram(buffer, QHostAddress(ip), port);
                QString str = QString("[%1:%2] %3").arg(ip).arg(port).arg(data);
                sendInfo(msgType_network_send, str, false);
            }break;

            default: break;
        }
    }
}

void King_serial::sendData()
{
    switch (ui->tabWidget_todo->currentIndex()) {
        case 0: { // 单条发送
            QString str = ui->textEdit_send->toPlainText();
            if (str.isEmpty()) {
                ui->textEdit_send->setFocus();
                return;
            }
            sendBuff(str);
            if (ui->checkBox_auto_clear->isChecked()) {
                ui->textEdit_send->clear();
                ui->textEdit_send->setFocus();
            }
        }break;

        case 1: { // 多条发送
            bool cur_mySend[10];
            int waitSend[10] = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1}; // 默认为-1 规避0的情况
            int waitSendNum = 0;
            static int sendIndex = 0; // 索引 指向当前需要发送的消息下标
            cur_mySend[0] = ui->checkBox_send0->checkState();
            cur_mySend[1] = ui->checkBox_send1->checkState();
            cur_mySend[2] = ui->checkBox_send2->checkState();
            cur_mySend[3] = ui->checkBox_send3->checkState();
            cur_mySend[4] = ui->checkBox_send4->checkState();
            cur_mySend[5] = ui->checkBox_send5->checkState();
            cur_mySend[6] = ui->checkBox_send6->checkState();
            cur_mySend[7] = ui->checkBox_send7->checkState();
            cur_mySend[8] = ui->checkBox_send8->checkState();
            cur_mySend[9] = ui->checkBox_send9->checkState();
            for (int i=0; i<10; i++) {
                if(cur_mySend[i] == true) { // 代表该条消息需要发送
                    waitSend[waitSendNum ++] = i;
                }
            }
            switch (waitSend[sendIndex++]) {
                case 0: on_pushButton_send0_clicked(); break;
                case 1: on_pushButton_send1_clicked(); break;
                case 2: on_pushButton_send2_clicked(); break;
                case 3: on_pushButton_send3_clicked(); break;
                case 4: on_pushButton_send4_clicked(); break;
                case 5: on_pushButton_send5_clicked(); break;
                case 6: on_pushButton_send6_clicked(); break;
                case 7: on_pushButton_send7_clicked(); break;
                case 8: on_pushButton_send8_clicked(); break;
                case 9: on_pushButton_send9_clicked(); break;
                default: sendIndex = 0; break;
            }
            if(sendIndex >= waitSendNum) { // 代表本周期轮询结束
                waitSendNum = 0;
                sendIndex = 0;
            }
        }break;

        default:break;
    }
}

void King_serial::timer_basic_task()
{
    static int delayCnt = 0;
    delayCnt ++;

    mySerial.new_serialportinfo = serial_getPortNameList();
    QString com = ui->comboBox_serial_portName->currentText();

    // 说明串口列表出现变化, 更新列表
    if(mySerial.old_serialportinfo.length() != mySerial.new_serialportinfo.length()) {
        mySerial.old_serialportinfo = mySerial.new_serialportinfo;
        if(!mySerial.new_serialportinfo.contains(com) && serialPort->isOpen()) {
            QMessageBox::critical(this, tr("Error"), "串口连接中断，请检查是否正确连接！");
            serialPort->close();
            mySerial.isOpen = false;
            serial_ui_control_setEnanble(true);
            ui->pushButton_serial_openOrclose->setIcon(QIcon(QString(":/pic/off.png")));
            ui->pushButton_serial_openOrclose->setText("打开串口");
            ui->comboBox_serial_portName->removeItem(ui->comboBox_serial_portName->currentIndex());
        }
        if(!serialPort->isOpen()) {       //串口关闭的时候
            ui->comboBox_serial_portName->clear();   //清空列表
            foreach(QString comname, mySerial.new_serialportinfo) {
                ui->comboBox_serial_portName->addItem(comname);
            }
        }
    }

    if (!myNetwork.isOpen && AppConfig::NetReConnect && delayCnt >=5 ) {
        delayCnt = 0;
        if (AppConfig::NetIP != "" && AppConfig::NetPort != 0) {
            tcpSocket->connectToHost(AppConfig::NetIP, quint16(AppConfig::NetPort));
            if (tcpSocket->waitForConnected(100)) {
                ui->pushButton_network_start->setText("关闭服务");
                sendInfo(msgType_network_send, "服务器重连成功",false);
                myNetwork.isOpen = true;
            }
        }
    }
}

void King_serial::on_checkBox_topShow_stateChanged(int arg1)
{
    Qt::WindowFlags m_flags;
    if(arg1 == 0) {
        m_flags = nullptr;
        setWindowFlags(m_flags);
    } else {
        m_flags = windowFlags();
        setWindowFlags(m_flags | Qt::WindowStaysOnTopHint);
    }
    show();
}

void King_serial::on_checkBox_auto_send_stateChanged(int arg1)
{
    timer_send->setInterval(ui->comboBox_auto_send->currentText().toInt());
    if(arg1 == 0) { // 代表未勾选
        ui->comboBox_auto_send->setEnabled(true);
        timer_send->stop();
    }else {
        ui->comboBox_auto_send->setEnabled(false);
        timer_send->start();
    }
}

void King_serial::on_checkBox_auto_save_stateChanged(int arg1)
{
    timer_save->setInterval(ui->comboBox_auto_save->currentText().toInt());
    if(arg1 == 0) {
        ui->comboBox_auto_save->setEnabled(true);
        timer_save->stop();
    } else {
        ui->comboBox_auto_save->setEnabled(false);
        timer_save->start();
    }
}

// 是否开启接收区数据显示
void King_serial::on_pushButton_pauseShow_clicked()
{
    if(mySerial.isShow == false) {
        mySerial.isShow = true;
        ui->pushButton_pauseShow->setText("暂停显示");
    }else {
        mySerial.isShow = false;
        ui->pushButton_pauseShow->setText("开启显示");
    }
}

// 是否开启接收区滚屏显示
void King_serial::on_pushButton_auto_scroll_clicked()
{
    if(mySerial.isScroll == false) {
        mySerial.isScroll = true;
        ui->textBrowser_recv->moveCursor(QTextCursor::End);
        ui->pushButton_auto_scroll->setText("暂停滚屏");
    }else {
        mySerial.isScroll = false;
        ui->textBrowser_recv->moveCursor(QTextCursor::NoMove);
        ui->pushButton_auto_scroll->setText("自动滚屏");
    }
}

// 清除接收区内容
void King_serial::on_pushButton_clear_recv_clicked()
{
    sendInfo(msgType_about, "", true);
}

void King_serial::on_tabWidget_currentChanged(int index)
{
    switch (index) {
        case 0: ui->statusBar->showMessage(ui->comboBox_serial_portName->currentText()); break;
        case 1: ui->statusBar->showMessage(QString("%1:%2")
                                           .arg(ui->comboBox_network_ip->currentText())
                                           .arg(ui->lineEdit_network_port->text())); break;
   }
}

/* ------------------------------------------------- 串口部分 ----------------------------------------------- */
/* ------------------------------------------------- 串口部分 ----------------------------------------------- */
/* ------------------------------------------------- 串口部分 ----------------------------------------------- */
void King_serial::serial_ui_control_setEnanble(bool state)
{
    ui->comboBox_serial_portName->setEnabled(state);
    ui->comboBox_serial_baudrate->setEnabled(state);
    ui->comboBox_serial_dataBit->setEnabled(state);
    ui->comboBox_serial_parityBit->setEnabled(state);
    ui->comboBox_serial_stopBit->setEnabled(state);
    ui->comboBox_serial_flow_control->setEnabled(state);
    if(!myNetwork.isOpen)ui->pushButton_send->setEnabled(!state);
}

void King_serial::serial_config()
{
    // 1.结构体成员参数初始化
    mySerial.isOpen = false;
    mySerial.isShow = true;
    mySerial.isScroll = true;
    mySerial.istimeStamp = true;
    mySerial.sendCount = 0;
    mySerial.recvCount = 0;
    mySerial.sleepTime = 10;
    serialPort = new QSerialPort();
    // 2.串口接收定时器初始化
    timer_serial_recv = new QTimer();
    timer_serial_recv->setInterval(10);
    connect(timer_serial_recv, SIGNAL(timeout()), this, SLOT(serial_recvData()));
    // 3.重写控件内容
    ui->comboBox_serial_baudrate->setCurrentIndex(ui->comboBox_serial_baudrate->findText(QString::number(AppConfig::BaudRate)));
    ui->comboBox_serial_dataBit->setCurrentIndex(ui->comboBox_serial_dataBit->findText(QString::number(AppConfig::DataBit)));
    ui->comboBox_serial_parityBit->setCurrentIndex(ui->comboBox_serial_parityBit->findText(AppConfig::Parity));
    ui->comboBox_serial_stopBit->setCurrentIndex(ui->comboBox_serial_stopBit->findText(QString::number(AppConfig::StopBit)));
    ui->comboBox_serial_flow_control->setCurrentIndex(ui->comboBox_serial_flow_control->findText(AppConfig::FlowControl));
    ui->textEdit_send->setPlainText(AppConfig::TextSend);
    // 4.连接需要绑定的控件信号与槽 绑定ini文件
    connect(ui->comboBox_serial_baudrate, SIGNAL(currentIndexChanged(int)), this, SLOT(saveConfig()));
    connect(ui->comboBox_serial_dataBit, SIGNAL(currentIndexChanged(int)), this, SLOT(saveConfig()));
    connect(ui->comboBox_serial_parityBit, SIGNAL(currentIndexChanged(int)), this, SLOT(saveConfig()));
    connect(ui->comboBox_serial_stopBit, SIGNAL(currentIndexChanged(int)), this, SLOT(saveConfig()));
    connect(ui->comboBox_serial_flow_control, SIGNAL(currentIndexChanged(int)), this, SLOT(saveConfig()));
    connect(ui->textEdit_send, SIGNAL(textChanged()), this, SLOT(saveConfig()));
    // 5.将串口号设置为文本左对齐显示
    ui->comboBox_serial_portName->addItems(serial_getPortNameList());
    serial_ui_control_setEnanble(true);
    // 6.设置按下 Enter 即可发送数据
    ui->textEdit_send->setFocus();
    ui->textEdit_send->installEventFilter(this);//设置完后自动调用其eventFilter函数
}

// 事件过滤器
bool King_serial::eventFilter(QObject *target, QEvent *event)
{
    if(target == ui->textEdit_send) {
        if(event->type() == QEvent::KeyPress) {//回车键
             QKeyEvent *k = static_cast<QKeyEvent *>(event);
             if(k->key() == Qt::Key_Return) {
                 sendData();
                 return true;
             }
        }
    }
    return QWidget::eventFilter(target, event);
}

QStringList King_serial::serial_getPortNameList()
{
    QStringList serialportinfo;
    foreach(QSerialPortInfo info, QSerialPortInfo::availablePorts()) {
        serialportinfo <<info.portName() + ": " + info.description();
    }
    return serialportinfo;
}

void King_serial::serial_recvData()
{
    if (serialPort->bytesAvailable() <= 0) {
        return;
    }
    sleep(mySerial.sleepTime);
    QString buffer;
    QByteArray data = serialPort->readAll();
    if (data.length() <= 0) return;
    if (mySerial.isShow) {
        if (ui->checkBox_hex_recv->isChecked()) {
            buffer = api::byteArrayToHexStr(data);
        } else {
            buffer = QString::fromLocal8Bit(data);
        }
        if(myModBus.isOpen) {
            sendInfo(msgType_modbus_recv, buffer, false);
        } else {
            sendInfo(msgType_serial_recv, buffer, false);
        }
        mySerial.recvCount = mySerial.recvCount + data.size();
        ui->pushButton_recvCount->setText(QString("接收: %1 字节").arg(mySerial.recvCount));
    }
    plot_updateData(data);
    modBus_analysisData(buffer);
}

void King_serial::serial_saveData()
{
    QString tempData = ui->textBrowser_recv->toPlainText();
    if (tempData.isEmpty()) {
        return;
    }

    QDateTime now = QDateTime::currentDateTime();
    QString name = now.toString("yyyy-MM-dd-HH-mm-ss");
    QString fileName = QString("%1/%2.txt").arg(appPath()).arg(name);

    QFile file(fileName);
    file.open(QFile::WriteOnly | QIODevice::Text);
    QTextStream out(&file);
    out << tempData;
    file.close();
    QMessageBox::about(this, "提示", QString("文件已保存在%1路径下").arg(appPath()));
    on_pushButton_clear_recv_clicked();
}

void King_serial::on_pushButton_serial_openOrclose_clicked()
{
    if(mySerial.isOpen == false) {
        mySerial.portName = ui->comboBox_serial_portName->currentText();
        mySerial.baudrate = ui->comboBox_serial_baudrate->currentText().toInt();
        mySerial.dataBit = ui->comboBox_serial_dataBit->currentIndex();
        mySerial.parityBit = ui->comboBox_serial_parityBit->currentIndex();
        mySerial.stopBit = ui->comboBox_serial_stopBit->currentIndex();
        mySerial.flowControl = ui->comboBox_serial_flow_control->currentIndex();

        // 1.配置串口号
        if(mySerial.portName.contains(":")) {
            mySerial.portName = mySerial.portName.split(":")[0];
        }
        serialPort->setPortName(mySerial.portName);
        // 2.配置串口波特率
        serialPort->setBaudRate(mySerial.baudrate);
        // 3.配置数据位
        switch(mySerial.dataBit) {
            case 0: serialPort->setDataBits(QSerialPort::Data8); break;
            case 1: serialPort->setDataBits(QSerialPort::Data7); break;
            case 2: serialPort->setDataBits(QSerialPort::Data6); break;
            case 3: serialPort->setDataBits(QSerialPort::Data5); break;
            default: serialPort->setDataBits(QSerialPort::UnknownDataBits); break;
        }
        // 4.配置校验位
        switch(mySerial.parityBit) {
            case 0: serialPort->setParity(QSerialPort::NoParity); break;
            case 1: serialPort->setParity(QSerialPort::EvenParity); break;
            case 2: serialPort->setParity(QSerialPort::OddParity); break;
            #ifdef Q_OS_WIN
                case 3: serialPort->setParity(QSerialPort::MarkParity); break;
            #endif
            case 4: serialPort->setParity(QSerialPort::SpaceParity); break;
            default: serialPort->setParity(QSerialPort::UnknownParity); break;
        }
        // 5.配置停止位
        switch(mySerial.stopBit) {
            case 0: serialPort->setStopBits(QSerialPort::OneStop); break;
            #ifdef Q_OS_WIN
                case 1: serialPort->setStopBits(QSerialPort::OneAndHalfStop); break;
            #endif
            case 2: serialPort->setStopBits(QSerialPort::TwoStop); break;
            default: serialPort->setStopBits(QSerialPort::UnknownStopBits); break;
        }
        // 6.配置流控制
        switch(mySerial.stopBit) {
            case 0: serialPort->setFlowControl(QSerialPort::NoFlowControl); break;
            case 1: serialPort->setFlowControl(QSerialPort::HardwareControl); break;
            case 2: serialPort->setFlowControl(QSerialPort::SoftwareControl); break;
            default: serialPort->setFlowControl(QSerialPort::UnknownFlowControl); break;
        }
        // 7.打开串口
        if(!serialPort->open(QIODevice::ReadWrite)) {
            QMessageBox::about(nullptr, "提示", "当前串口可能被占用\r\n无法打开串口!!!");
            return;
        }
        mySerial.isOpen = true;
        timer_serial_recv->start();
        ui->pushButton_serial_openOrclose->setIcon(QIcon(QString(":/pic/on.png")));
        ui->pushButton_serial_openOrclose->setText("关闭串口");
        serial_ui_control_setEnanble(false);
    } else {
        mySerial.isOpen = false;
        timer_serial_recv->stop();
        serialPort->close();
        ui->pushButton_serial_openOrclose->setIcon(QIcon(QString(":/pic/off.png")));
        ui->pushButton_serial_openOrclose->setText("打开串口");
        serial_ui_control_setEnanble(true);
    }
}

void King_serial::on_pushButton_sendCount_clicked()
{
    mySerial.sendCount = 0;
    ui->pushButton_sendCount->setText("发送: 0 字节");
}

void King_serial::on_pushButton_recvCount_clicked()
{
    mySerial.recvCount = 0;
    ui->pushButton_recvCount->setText("接收: 0 字节");
}

void King_serial::on_comboBox_serial_portName_currentIndexChanged(const QString &arg1)
{
    if(ui->tabWidget->currentIndex() == 0) {
        ui->statusBar->showMessage(arg1);
    }
}

void King_serial::on_pushButton_send0_clicked()
{
    QString str = ui->lineEdit_send0->text();
    if(str.isEmpty()) {
        ui->lineEdit_send0->setFocus();
        return;
    }
    if(ui->checkBox_auto_clear->isChecked()) {
        ui->lineEdit_send0->setText("");
        ui->lineEdit_send0->setFocus();
    }
    sendBuff(str);
}

void King_serial::on_pushButton_send1_clicked()
{
    QString str = ui->lineEdit_send1->text();
    if(str.isEmpty()) {
        ui->lineEdit_send1->setFocus();
        return;
    }
    if(ui->checkBox_auto_clear->isChecked()) {
        ui->lineEdit_send1->setText("");
        ui->lineEdit_send1->setFocus();
    }
    sendBuff(str);
}

void King_serial::on_pushButton_send2_clicked()
{
    QString str = ui->lineEdit_send2->text();
    if(str.isEmpty()) {
        ui->lineEdit_send2->setFocus();
        return;
    }
    if(ui->checkBox_auto_clear->isChecked()) {
        ui->lineEdit_send2->setText("");
        ui->lineEdit_send2->setFocus();
    }
    sendBuff(str);
}

void King_serial::on_pushButton_send3_clicked()
{
    QString str = ui->lineEdit_send3->text();
    if(str.isEmpty()) {
        ui->lineEdit_send3->setFocus();
        return;
    }
    if(ui->checkBox_auto_clear->isChecked()) {
        ui->lineEdit_send3->setText("");
        ui->lineEdit_send3->setFocus();
    }
    sendBuff(str);
}

void King_serial::on_pushButton_send4_clicked()
{
    QString str = ui->lineEdit_send4->text();
    if(str.isEmpty()) {
        ui->lineEdit_send4->setFocus();
        return;
    }
    if(ui->checkBox_auto_clear->isChecked()) {
        ui->lineEdit_send4->setText("");
        ui->lineEdit_send4->setFocus();
    }
    sendBuff(str);
}

void King_serial::on_pushButton_send5_clicked()
{
    QString str = ui->lineEdit_send5->text();
    if(str.isEmpty()) {
        ui->lineEdit_send5->setFocus();
        return;
    }
    if(ui->checkBox_auto_clear->isChecked()) {
        ui->lineEdit_send5->setText("");
        ui->lineEdit_send5->setFocus();
    }
    sendBuff(str);
}

void King_serial::on_pushButton_send6_clicked()
{
    QString str = ui->lineEdit_send6->text();
    if(str.isEmpty()) {
        ui->lineEdit_send6->setFocus();
        return;
    }
    if(ui->checkBox_auto_clear->isChecked()) {
        ui->lineEdit_send6->setText("");
        ui->lineEdit_send6->setFocus();
    }
    sendBuff(str);
}

void King_serial::on_pushButton_send7_clicked()
{
    QString str = ui->lineEdit_send7->text();
    if(str.isEmpty()) {
        ui->lineEdit_send7->setFocus();
        return;
    }
    if(ui->checkBox_auto_clear->isChecked()) {
        ui->lineEdit_send7->setText("");
        ui->lineEdit_send7->setFocus();
    }
    sendBuff(str);
}

void King_serial::on_pushButton_send8_clicked()
{
    QString str = ui->lineEdit_send8->text();
    if(str.isEmpty()) {
        ui->lineEdit_send8->setFocus();
        return;
    }
    if(ui->checkBox_auto_clear->isChecked()) {
        ui->lineEdit_send8->setText("");
        ui->lineEdit_send8->setFocus();
    }
    sendBuff(str);
}

void King_serial::on_pushButton_send9_clicked()
{
    QString str = ui->lineEdit_send9->text();
    if(str.isEmpty()) {
        ui->lineEdit_send9->setFocus();
        return;
    }
    if(ui->checkBox_auto_clear->isChecked()) {
        ui->lineEdit_send9->setText("");
        ui->lineEdit_send9->setFocus();
    }
    sendBuff(str);
}

/* ------------------------------------------------- 波形部分 ----------------------------------------------- */
/* ------------------------------------------------- 波形部分 ----------------------------------------------- */
/* ------------------------------------------------- 波形部分 ----------------------------------------------- */
void King_serial::plot_config()
{
    // 1. myPlot结构体初始化
    myPlot.isOpen = false;
    myPlot.isEnlarge = false;
    myPlot.autoRefresh_Y = true;
    myPlot.x_point_cnt = 0;
    myPlot.plotNum = 0;
    myPlot.x_minValue = 0;
    myPlot.x_maxValue = ui->spinBox_xPoints->text().toInt();
    myPlot.y_minValue = -1;
    myPlot.y_maxValue = 1;

    ui->splitter_leftAndRight->setSizes({180, width()-180});
    ui->splitter_upAndDown->setSizes({(height()-180)/3, (height()-180)*2/3, 180});

    ui->spinBox_xPoints->setValue(AppConfig::PlotObserveNum);
    connect(ui->spinBox_xPoints, SIGNAL(valueChanged(int)), this, SLOT(saveConfig()));

    /* For channel data (gruvbox palette) */
    myPlot.line_colors[ 0] = QColor("#fb4934");
    myPlot.line_colors[ 1] = QColor("#b8bb26");
    myPlot.line_colors[ 2] = QColor("#fabd2f");
    myPlot.line_colors[ 3] = QColor("#83a598");
    myPlot.line_colors[ 4] = QColor("#d3869b");
    myPlot.line_colors[ 5] = QColor("#8ec07c");
    myPlot.line_colors[ 6] = QColor("#fe8019");
    myPlot.line_colors[ 7] = QColor("#cc241d");
    myPlot.line_colors[ 8] = QColor("#98971a");
    myPlot.line_colors[ 9] = QColor("#d79921");
    myPlot.line_colors[10] = QColor("#458588");
    myPlot.line_colors[11] = QColor("#b16286");

    param.head = AppConfig::PlotHead;
    param.tail = AppConfig::PlotTail;
    param.channel_name_split = AppConfig::PlotChannelNameSplit;
    param.channel_data_split = AppConfig::PlotChannelDataSplit;

    // 1.波形界面初始化
    plotSet = new plotSetting(this);
    connect(plotSet, SIGNAL(get_paramData(struct_param_typedef, bool)), this, SLOT(analysis_Data(struct_param_typedef, bool)));
    // 2.创建Plot对象
    customPlot = ui->customPlot;
    customPlot->setBackground(QBrush(PlotUIColor));
    // 3.配置x轴格式
    customPlot->xAxis->setRange(myPlot.x_minValue, myPlot.x_maxValue);
    //customPlot->xAxis->setTickLengthIn(4);       // 轴线内刻度的长度
    //customPlot->xAxis->setTickLengthOut(5);      // 轴线外刻度的长度
    //customPlot->xAxis->setLabel("x轴");
    customPlot->xAxis->setTickLabels(false);
    customPlot->xAxis->setUpperEnding(QCPLineEnding::esSpikeArrow);  // 设置轴线结束实角三角形但内部有凹陷的形状
    customPlot->xAxis->setSelectableParts(QCPAxis::spAxis | QCPAxis::spAxisLabel | QCPAxis::spTickLabels);// 轴的三个部分都可以被选择
    // 4.配置y轴格式
    customPlot->yAxis->setRange(myPlot.y_minValue, myPlot.y_maxValue);
    customPlot->yAxis->setTickLengthIn(4);       // 轴线内刻度的长度
    customPlot->yAxis->setTickLengthOut(5);      // 轴线外刻度的长度
    //customPlot->yAxis->setLabel("y轴");
    customPlot->yAxis->setUpperEnding(QCPLineEnding::esSpikeArrow);  // 设置轴线结束实角三角形但内部有凹陷的形状
    customPlot->yAxis->setSelectableParts(QCPAxis::spAxis | QCPAxis::spAxisLabel | QCPAxis::spTickLabels);// 轴的三个部分都可以被选择
    // 5.边框右侧和上侧均显示刻度线，但不显示刻度值
    customPlot->xAxis2->setVisible(false);
    customPlot->xAxis2->setTickLabels(false);
    customPlot->yAxis2->setVisible(false);
    customPlot->yAxis2->setTickLabels(false);
    // 6.图例配置
    customPlot->legend->setVisible(false);                      // 初始化先关闭图例显示 因为图例边框没有隐藏
    //customPlot->legend->setBorderPen(Qt::NoPen);              // 设置图例边框隐藏
    customPlot->legend->setFont(QFont("Consolas", 12));         // 设置字体
    customPlot->legend->setBrush(QColor(255, 255, 255, 0));     // 设置图例背景 黑色 透明
    customPlot->legend->setWrap(12);                            // 设置纵轴为12个图例自动换行
    customPlot->legend->setSelectableParts(QCPLegend::spItems); // 设置legend选择图例 图例本身不能被选择，只有里面的项可以被选择
    customPlot->legend->setSelectedIconBorderPen(Qt::NoPen);    // 设置图例里的项被选择时不显示Icon的边框
    customPlot->axisRect()->insetLayout()->setInsetAlignment(0, Qt::AlignTop |Qt::AlignLeft);// 让图例居左上
    customPlot->setNotAntialiasedElements (QCP::aeAll);                                     // 用于提高性能
    // 7.设置基本坐标轴（左侧Y轴和下方X轴）可拖动、可缩放、曲线可选、legend可选、设置伸缩比例，使所有图例可见
    customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectAxes | QCP::iSelectLegend | QCP::iSelectPlottables);
    customPlot->setMultiSelectModifier(Qt::ControlModifier);            // 使用ctrl键来多选

    // 8.使上下两个X轴的范围总是相等，使左右两个Y轴的范围总是相等
    connect(customPlot->xAxis, SIGNAL(rangeChanged(QCPRange)), customPlot->xAxis2, SLOT(setRange(QCPRange)));
    connect(customPlot->yAxis, SIGNAL(rangeChanged(QCPRange)), customPlot->yAxis2, SLOT(setRange(QCPRange)));
    // 7.绑定信号与槽
    connect(customPlot, SIGNAL(mouseWheel(QWheelEvent*)), this, SLOT(wheelEvent(QWheelEvent*)));
    connect(customPlot, SIGNAL(mouseMove(QMouseEvent*)), this, SLOT(mouseMoveEvent(QMouseEvent*)));
    connect(customPlot, SIGNAL(selectionChangedByUser()), this, SLOT(selectionChanged()));
    connect (customPlot, SIGNAL(legendDoubleClick(QCPLegend*, QCPAbstractLegendItem*, QMouseEvent*)), this, SLOT(legend_double_click (QCPLegend*, QCPAbstractLegendItem*, QMouseEvent*)));
}

// 重写鼠标滚轮事件 鼠标滚轮缩放
void King_serial::wheelEvent(QWheelEvent *event)
{
    Q_UNUSED(event);
    int x = this->mapFromGlobal(QCursor().pos()).x();
    int y = this->mapFromGlobal(QCursor().pos()).y();
    // 判断鼠标是否在波形图上
    if(x>customPlot->pos().x() && x<customPlot->pos().x()+customPlot->width() &&
       y>customPlot->pos().y() && y<customPlot->pos().y()+customPlot->height()) {
        myPlot.autoRefresh_Y = false;
        ui->pushButton_plot_autoOrHand->setIcon(QIcon(QString("%1/hand.png").arg(IconUrl)));

        if (customPlot->xAxis->selectedParts().testFlag(QCPAxis::spAxis)) {
             customPlot->axisRect()->setRangeZoom(ui->customPlot->xAxis->orientation());
        } else if (customPlot->yAxis->selectedParts().testFlag(QCPAxis::spAxis)) {
            customPlot->axisRect()->setRangeZoom(ui->customPlot->yAxis->orientation());
        } else {
            customPlot->axisRect()->setRangeZoom(Qt::Horizontal | Qt::Vertical);
        }
    }
}

// 鼠标移动增改横轴点数
void King_serial::mouseMoveEvent(QMouseEvent *e)
{
    if(e->buttons() == Qt::LeftButton) {
        if(King_serial::isMaximized() || King_serial::isMinimized()) {
            return;
        } else {
            if (ui->horizontalLayout->geometry().contains(this->mapFromGlobal(QCursor::pos()))) {// 获取鼠标当前是否悬浮在相应控件上
                move(e->globalPos() - m_point);
            }
        }
    }

    if (customPlot->graphCount() == 0)  return;
    // 获取鼠标坐标，相对父窗体坐标
    int x_pos = e->pos().x();
    int y_pos = e->pos().y();

    // 鼠标坐标转化为CustomPlot内部坐标
    double x_val = customPlot->xAxis->pixelToCoord(x_pos);
    double y_val = customPlot->yAxis->pixelToCoord(y_pos);

    // 通过坐标轴范围判断光标是否在点附近
    double x_begin = customPlot->xAxis->range().lower;
    double x_end   = customPlot->xAxis->range().upper;
    double y_begin = customPlot->yAxis->range().lower;
    double y_end   = customPlot->yAxis->range().upper;

    // 光标与最近点距离在此范围内，便显示该最近点的值
    double x_tolerate = (x_end - x_begin) / 40;
    double y_tolerate = (y_end - y_begin) / 40;

    // 判断有没有超出坐标轴范围
    if (x_val < x_begin || x_val > x_end)   return;

    // 通过x值查找离曲线最近的一个key值索引
    int index = 0;
    int index_left   = customPlot->graph(0)->findBegin(x_val, true);  // 左边最近的一个key值索引
    int index_right  = customPlot->graph(0)->findEnd(x_val, true);    // 右边最近的一个key值索引
    double dif_left  = std::abs(customPlot->graph(0)->data()->at(index_left)->key - x_val);
    double dif_right = std::abs(customPlot->graph(0)->data()->at(index_right)->key - x_val);
    if (dif_left < dif_right)   index = index_left;
    else                        index = index_right;

    x_val = customPlot->graph(0)->data()->at(index)->key;// 通过得到的索引获取key值

    int graphIndex=0;// curve index closest to the cursor
    double dx = std::abs(x_val - customPlot->xAxis->pixelToCoord(x_pos));
    double dy = std::abs(customPlot->graph(0)->data()->at(index)->value - y_val);

    // 通过遍历每条曲线在index处的value值，得到离光标点最近的value及对应曲线索引
    for (int i = 0; i < customPlot->xAxis->graphs().count(); i++) {
        if (std::abs(customPlot->graph(i)->data()->at(index)->value - y_val)<dy) {
            dy = std::abs(customPlot->graph(i)->data()->at(index)->value - y_val);
            graphIndex = i;
        }
    }
    if(customPlot->graph(graphIndex)->visible()) {
        QString strToolTip = QString("%1\n(%2,%3)").arg(customPlot->graph(graphIndex)->name())
                                                   .arg(QString::number(int(x_val)))
                                                   .arg(QString::number(customPlot->graph(graphIndex)->data()->at(index)->value));
        //判断光标点与最近点的距离是否在设定范围内
        if (dy < y_tolerate && dx < x_tolerate) QToolTip::showText(cursor().pos(), strToolTip, customPlot);
    }
}

// 设置可选中图例或曲线
void King_serial::selectionChanged()
{
    // 将图形的选择与相应图例项的选择同步
    for (int i=0; i<customPlot->graphCount(); ++i) {
        QCPGraph *graph = customPlot->graph(i);
        QCPPlottableLegendItem *item = customPlot->legend->itemWithPlottable(graph);
        if (item->selected()) { // 选中图例决定是否隐藏该曲线
            if(graph->visible()) {
                graph->setVisible(false);
                item->setTextColor(QColor(0,0,0,128));
            } else {
                graph->setVisible(true);
                item->setTextColor(QColor(0,0,0,255));
            }
        }
        if (graph->selected()){ // 选中曲线高亮该曲线
            item->setSelected(true);
            item->setFont(QFont("Consolas", 16));
        } else {
            item->setSelected(false);
            item->setFont(QFont("Consolas", 12));
        }
    }
}

// 双击可更改当前通道的图例名称
void King_serial::legend_double_click(QCPLegend *legend, QCPAbstractLegendItem *item, QMouseEvent *event)
{
    Q_UNUSED(legend)
    Q_UNUSED(event)
    /* 只有在点击双击图例才触发，防止误触发 */
    if(item) {
        QCPPlottableLegendItem *plItem = qobject_cast<QCPPlottableLegendItem*>(item);
        bool ok;
        QString newName = QInputDialog::getText(this,
                                                "Change channel name",
                                                "New name:",
                                                QLineEdit::Normal,
                                                plItem->plottable()->name(),
                                                &ok, Qt::Popup);
        if (ok) {
            plItem->plottable()->setName(newName);
            customPlot->replot(QCustomPlot::rpQueuedReplot);// 更新绘图 rpQueuedReplot:可避免重复绘图
        }
    }
}

// 串口波形数据解析
void King_serial::plot_updateData(QByteArray data)
{
    static QString buffer;
    static quint8 delay = 0;
    static int channel_maxValue = 0; // 数据最大值的通道

    QString head = param.head.remove(" ");
    QString tail = param.tail.remove(" ");

    if(myPlot.isOpen) {
        buffer += data;
        delay ++;
        if(buffer.startsWith(head) && buffer.contains(tail)) {      // 接收到帧头和帧尾 兼容帧尾后存在"\r\n"的情况
            buffer.remove(buffer.left(head.size()));    // 移除帧头
            buffer = buffer.left(buffer.indexOf(tail)); // 取 剩余数据中 帧尾左侧的数据
            // -------------------- 从此处开始才是需要处理的数据 --------------------
            QStringList nameList;
            QStringList dataList;
            nameList = buffer.split(param.channel_name_split); // 通道名称列表
            int nameMaxNum = nameList.size()-1;
            if(nameMaxNum == -1) { /* 代表没有通道名称 */
                dataList = buffer.split(param.channel_data_split); // 通道数据列表
            } else {
                dataList = nameList[nameMaxNum].split(param.channel_data_split); // 通道数据列表
            }
            int dataMaxNum = dataList.size()-1;
            // 数据异常不处理
            if(nameMaxNum > dataMaxNum) {
                customPlot->legend->setVisible(false); // 设置图例不可见
                buffer.clear();
                return;
            }
            // 通道名称≤数据名称 期望自适应图例通道数
            nameList.removeAt(nameMaxNum);
            for(int i=0; i<(dataMaxNum-nameMaxNum); i++) {
                nameList <<" ";
            }
            buffer.clear(); // 之后就没有用到buffer缓存了 所以先清空
            customPlot->legend->setVisible(true); // 设置图例可见
            // 1.首先获取当前波形图中的曲线个数
            int wave_num = customPlot->graphCount();
            if(wave_num <= dataMaxNum) {
                for(int i=wave_num; i<dataMaxNum; i++) {
                    customPlot->addGraph();
                    customPlot->graph(i)->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssCircle, 0.005));// 设置图表散点样式:圆点 大小为0.005
                    customPlot->graph(i)->setLineStyle((QCPGraph::LineStyle::lsStepRight));// 设置图表线段的风格
                    if(nameList[i] == " ") {
                        customPlot->graph(i)->setName(QString("Channel %1").arg(i));
                    } else {
                        customPlot->graph(i)->setName(nameList[i]);
                    }
                    if(i < 12) { // 低于12通道使用自定义的通道数据颜色
                        customPlot->graph(i)->setPen(QPen(myPlot.line_colors[i], 1.5));
                    } else { // 大于12通道使用随机颜色
                        customPlot->graph(i)->setPen(QPen(QColor::fromHsl(rand()%256, rand()%256, rand()%256), 1.5));
                    }
                }
            } else {
                for(int i=dataMaxNum; i<wave_num; ++i) {
                    customPlot->removeGraph(i);
                }
            }

            // 3.波形数据更新
            for(int i=0; i<dataMaxNum; i++) {
                // 动态Y轴 范围算法-获取Y轴上波形数据的最大值和最小值（当该波形未被隐藏时生效）
                if(customPlot->graph(i)->visible()) {
                    if(dataList[i].toDouble() < myPlot.y_minValue) {
                        myPlot.y_minValue = dataList[i].toDouble();
                    }
                    if(dataList[i].toDouble() > myPlot.y_maxValue) {
                        channel_maxValue = i; // 记录当前波形的通道值
                        myPlot.y_maxValue = dataList[i].toDouble();
                    }
                }
                if(customPlot->graph(channel_maxValue)->visible() == false) {
                    myPlot.y_maxValue = myPlot.y_minValue;
                }
                customPlot->graph(i)->addData(myPlot.x_point_cnt, dataList[i].toDouble());
            }
            myPlot.x_point_cnt ++;
            if(myPlot.autoRefresh_Y) {
                double y_range = fabs(myPlot.y_maxValue)*2;
                customPlot->yAxis->setRange(-y_range, y_range);
            }
            customPlot->xAxis->setRange((myPlot.x_point_cnt-(ui->spinBox_xPoints->value())),
                                        (myPlot.x_point_cnt+(ui->spinBox_xPoints->value()/100)));
            customPlot->replot(QCustomPlot::rpQueuedReplot);// 更新绘图 rpQueuedReplot:可避免重复绘图
        } else if (delay >= 10) { // 超时时间 100ms还没接收到数据
            delay = 0;
            buffer.clear();
        }
    }
}

void King_serial::on_pushButton_plot_start_clicked()
{
    if(myPlot.isOpen == false) {
        myPlot.isOpen = true;
        ui->pushButton_plot_start->setToolTip("暂停绘图");
        ui->pushButton_plot_start->setIcon(QIcon(QString("%1/start.png").arg(IconUrl)));
    } else {
        myPlot.isOpen = false;
        ui->pushButton_plot_start->setToolTip("开始绘图");
        ui->pushButton_plot_start->setIcon(QIcon(QString("%1/stop.png").arg(IconUrl)));
    }
}

void King_serial::on_pushButton_plot_setting_clicked()
{
    myPlot.isOpen = false;
    plotSet->show();
}

//与主窗口相连的槽函数
void King_serial::analysis_Data(struct_param_typedef data, bool isOk)
{
    if(isOk)param = data;
    myPlot.isOpen = true;
}

void King_serial::on_pushButton_plot_refresh_clicked()
{
    customPlot->clearGraphs();
    customPlot->legend->setVisible(false); // 设置图例不可见
    customPlot->replot(QCustomPlot::rpQueuedReplot);// 更新绘图 rpQueuedReplot:可避免重复绘图
}

void King_serial::on_pushButton_plot_autoOrHand_clicked()
{
    if(myPlot.autoRefresh_Y) {
        myPlot.autoRefresh_Y = false;
        ui->pushButton_plot_autoOrHand->setToolTip("Y轴手动调整");
        ui->pushButton_plot_autoOrHand->setIcon(QIcon(QString("%1/hand.png").arg(IconUrl)));
    } else {
        myPlot.autoRefresh_Y = true;
        ui->pushButton_plot_autoOrHand->setToolTip("Y轴自适应");
        ui->pushButton_plot_autoOrHand->setIcon(QIcon(QString("%1/auto.png").arg(IconUrl)));
    }
}

void King_serial::on_pushButton_plot_hideOrShow_clicked()
{
    ui->pushButton_plot_hideOrShow->setIcon(QIcon(QString("%1/hide.png").arg(IconUrl)));
    for(int i=0; i<customPlot->graphCount(); i++) {
        customPlot->graph(i)->setVisible(false);
        customPlot->legend->itemWithPlottable(customPlot->graph(i))->setTextColor(QColor(0,0,0,128));
    }
}

void King_serial::on_pushButton_plot_save_clicked()
{
    on_pushButton_plot_start_clicked();
    QString filename = QFileDialog::getSaveFileName(this,
                                                    tr("Save File"),
                                                    tr(""),
                                                    tr("Image Files (*.png);;"
                                                       "Image Files (*.jpg);;"
                                                       "Image Files (*.jpeg);;"
                                                       "Image Files (*.bmp);;"
                                                       "Image Files (*.pdf)"));
    if( filename == "" ) {
        on_pushButton_plot_start_clicked();
        return;
    }
    if( filename.endsWith(".png") ){
        QMessageBox::information(this, "success", "成功保存为png文件");
        customPlot->savePng(filename, customPlot->width(), customPlot->height() );
    } else if( filename.endsWith(".jpg") || filename.endsWith(".jpeg") ){
        QMessageBox::information(this, "success", "成功保存为jpg文件");
        customPlot->saveJpg( filename, customPlot->width(), customPlot->height() );
    } else if( filename.endsWith(".bmp") ){
        QMessageBox::information(this, "success", "成功保存为bmp文件");
        customPlot->saveBmp( filename, customPlot->width(), customPlot->height() );
    } else if( filename.endsWith(".pdf") ){
        QMessageBox::information(this, "success", "成功保存为pdf文件");
        customPlot->savePdf( filename, customPlot->width(), customPlot->height() );
    } else{
        //否则追加后缀名为.png保存文件
        QMessageBox::information(this,"success","保存成功,已默认保存为png文件");
        customPlot->savePng(filename.append(".png"), customPlot->width(), customPlot->height());
    }
    on_pushButton_plot_start_clicked();
}

void King_serial::on_pushButton_plot_resize_clicked()
{
    if(myPlot.isEnlarge == false) {
        myPlot.isEnlarge = true;
        ui->pushButton_plot_resize->setToolTip("缩小");
        ui->pushButton_plot_resize->setIcon(QIcon(QString("%1/small.png").arg(IconUrl)));
        ui->splitter_leftAndRight->setSizes({0, width()});
        ui->splitter_upAndDown->setSizes({height(), 0, 0});
    } else {
        myPlot.isEnlarge = false;
        ui->pushButton_plot_resize->setToolTip("放大");
        ui->pushButton_plot_resize->setIcon(QIcon(QString("%1/large.png").arg(IconUrl)));
        ui->splitter_leftAndRight->setSizes({180, width()-180});
        ui->splitter_upAndDown->setSizes({(height()-180)/3, (height()-180)*2/3, 180});
    }
}

/* ------------------------------------------------- 网络部分 ----------------------------------------------- */
/* ------------------------------------------------- 网络部分 ----------------------------------------------- */
/* ------------------------------------------------- 网络部分 ----------------------------------------------- */
void King_serial::network_config()
{
    // 1.结构体成员参数初始化
    myNetwork.isOpen = false;
    // 2.tcpServer服务端初始化
    tcpServer = new TcpServer(this);
    connect(tcpServer, SIGNAL(connected(QString, int)), this, SLOT(tcpServer_connected(QString, int)));
    connect(tcpServer, SIGNAL(disconnected(QString, int)), this, SLOT(tcpServer_disconnected(QString, int)));
    connect(tcpServer, SIGNAL(error(QString, int, QString)), this, SLOT(tcpServer_error(QString, int, QString)));
    connect(tcpServer, SIGNAL(sendData(QString, int, QString)), this, SLOT(tcpServer_sendData(QString, int, QString)));
    connect(tcpServer, SIGNAL(receiveData(QString, int, QString)), this, SLOT(tcpServer_recvData(QString, int, QString)));
    // 3.tcpSocket客户端初始化
    tcpSocket = new QTcpSocket(this);
    connect(tcpSocket, SIGNAL(connected()), this, SLOT(tcpSocket_connected()));
    connect(tcpSocket, SIGNAL(disconnected()), this, SLOT(tcpSocket_disconnected()));
    connect(tcpSocket, SIGNAL(readyRead()), this, SLOT(tcpSocket_recvData()));
    #if (QT_VERSION >= QT_VERSION_CHECK(6,0,0))
        connect(tcpSocket, SIGNAL(errorOccurred(QAbstractSocket::SocketError)), this, SLOT(tcpSocket_error()));
    #else
        connect(tcpSocket, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(tcpSocket_error()));
    #endif
    // 4.udpServer服务端初始化
    udpServer = new QUdpSocket(this);
    connect(udpServer, SIGNAL(readyRead()), this, SLOT(udpServer_recvData()));
    #if (QT_VERSION >= QT_VERSION_CHECK(6,0,0))
        connect(udpServer, SIGNAL(errorOccurred(QAbstractSocket::SocketError)), this, SLOT(udpServer_error()));
    #else
        connect(udpServer, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(udpServer_error()));
    #endif
    // 5.udpSocket客户端初始化
    udpSocket = new QUdpSocket(this);
    connect(udpSocket, SIGNAL(readyRead()), this, SLOT(udpSocket_recvData()));
    #if (QT_VERSION >= QT_VERSION_CHECK(6,0,0))
        connect(udpSocket, SIGNAL(errorOccurred(QAbstractSocket::SocketError)), this, SLOT(udpSocket_error()));
    #else
        connect(udpSocket, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(udpSocket_error()));
    #endif
    // 6.重写控件内容
    ui->comboBox_network_mode->setCurrentIndex(ui->comboBox_network_mode->findText(AppConfig::NetMode));
    ui->comboBox_network_ip->setCurrentText(QString(AppConfig::NetIP));
    ui->comboBox_network_ip->addItem(network_getLocalIp());
    ui->lineEdit_network_port->setText(QString::number((AppConfig::NetPort)));
    ui->comboBox_network_udpIp->setCurrentText(QString(AppConfig::NetUDPIP));
    ui->lineEdit_network_udpPort->setText(QString::number((AppConfig::NetUDPPort)));
    ui->checkBox_network_reconnect->setChecked(AppConfig::NetReConnect);
    ui->checkBox_network_sendToAnyone->setChecked(AppConfig::NetSendAll);

    // 7.连接需要绑定的控件信号与槽 绑定ini文件
    connect(ui->comboBox_network_mode, SIGNAL(currentIndexChanged(int)), this, SLOT(saveConfig()));
    connect(ui->comboBox_network_ip, SIGNAL(currentIndexChanged(int)), this, SLOT(saveConfig()));
    connect(ui->lineEdit_network_port, SIGNAL(textChanged(QString)), this, SLOT(saveConfig()));
    connect(ui->checkBox_network_reconnect, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));
    connect(ui->checkBox_network_sendToAnyone, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));

    on_comboBox_network_mode_currentIndexChanged(ui->comboBox_network_mode->currentIndex());
    if(!mySerial.isOpen)ui->pushButton_send->setEnabled(false);
}

void King_serial::network_ui_control_setEnanble(bool state)
{
    myNetwork.isOpen = !state;
    ui->comboBox_network_mode->setEnabled(state);
    ui->comboBox_network_ip->setEnabled(state);
    ui->lineEdit_network_port->setEnabled(state);
    if(myNetwork.mode == NetMode_UdpSocket) {
        ui->comboBox_network_udpIp->setEnabled(state);
        ui->lineEdit_network_udpPort->setEnabled(state);
    }
    if(!mySerial.isOpen)ui->pushButton_send->setEnabled(!state);
}

// 获取本地ip地址
QString King_serial::network_getLocalIp()
{
    QList<QHostAddress> list =QNetworkInterface::allAddresses();
    foreach (QHostAddress address, list) {
       if(address.protocol() == QAbstractSocket::IPv4Protocol)
           return address.toString(); // 使用IPv4地址
    }
    return nullptr;
}

void King_serial::network_ui_server_isShow(bool show)
{
    if(show) {
        ui->label_clientList->show();
        ui->listWidget_network_clientList->show();
        ui->checkBox_network_sendToAnyone->show();
        ui->pushButton_network_remove->show();
    } else {
        ui->label_clientList->hide();
        ui->listWidget_network_clientList->hide();
        ui->checkBox_network_sendToAnyone->hide();
        ui->pushButton_network_remove->hide();
    }
}

void King_serial::on_comboBox_network_mode_currentIndexChanged(int index)
{
    switch (index) {
        case NetMode_TcpServer: { // TCP Server
            ui->label_network_ip->setText("监听地址");
            ui->label_network_port->setText("监听端口");
            ui->pushButton_network_start->setText("启动监听");
            network_ui_server_isShow(true);
            ui->checkBox_network_reconnect->hide();
            ui->label_network_udpIp->hide();
            ui->label_network_udpPort->hide();
            ui->comboBox_network_udpIp->hide();
            ui->lineEdit_network_udpPort->hide();
        }break;

        case NetMode_TcpSocket: { // TCP Client
            ui->label_network_ip->setText("远程地址");
            ui->label_network_port->setText("远程端口");
            ui->pushButton_network_start->setText("启动服务");
            network_ui_server_isShow(false);
            ui->checkBox_network_reconnect->show();
            ui->label_network_udpIp->hide();
            ui->label_network_udpPort->hide();
            ui->comboBox_network_udpIp->hide();
            ui->lineEdit_network_udpPort->hide();
        }break;

        case NetMode_UdpServer: { // UDP Server
            ui->label_network_ip->setText("监听地址");
            ui->label_network_port->setText("监听端口");
            ui->pushButton_network_start->setText("开启监听");
            network_ui_server_isShow(true);
            ui->checkBox_network_reconnect->hide();
            ui->label_network_udpIp->hide();
            ui->label_network_udpPort->hide();
            ui->comboBox_network_udpIp->hide();
            ui->lineEdit_network_udpPort->hide();
        }break;

        case NetMode_UdpSocket: { // UDP Client
            ui->label_network_ip->setText("本地地址");
            ui->label_network_port->setText("本地端口");
            ui->pushButton_network_start->setText("连接");
            network_ui_server_isShow(false);
            ui->checkBox_network_reconnect->hide();
            ui->label_network_udpIp->show();
            ui->label_network_udpPort->show();
            ui->comboBox_network_udpIp->show();
            ui->lineEdit_network_udpPort->show();
        }break;

        default: break;
    }
}

void King_serial::on_comboBox_network_ip_currentIndexChanged(const QString &arg1)
{
    if(ui->tabWidget->currentIndex() == 1) {
        ui->statusBar->showMessage(QString("%1:%2").arg(arg1).arg(ui->lineEdit_network_port->text()));
    }
}

void King_serial::on_pushButton_network_remove_clicked()
{
    if(myNetwork.mode == NetMode_TcpServer) {
        if (ui->checkBox_network_sendToAnyone->isChecked()) {
            tcpServer->remove();
        } else {
            int row = ui->listWidget_network_clientList->currentRow();
            if (row >= 0) {
                QString str = ui->listWidget_network_clientList->item(row)->text();
                QStringList list = str.split(":");
                tcpServer->remove(list.at(0), list.at(1).toInt());
            }
        }
    } else if(myNetwork.mode == NetMode_UdpServer) {
        if (ui->checkBox_network_sendToAnyone->isChecked()) {
            ui->listWidget_network_clientList->clear();
        } else {
            int row = ui->listWidget_network_clientList->currentRow();
            if (row >= 0) {
                delete ui->listWidget_network_clientList->takeItem(row);
            }
        }
    }
}

// 使用正则表达式判断是否是正确的IP地址
bool King_serial::isIpAddr(QString ip)
{
    QRegExp rx("^((25[0-5]|2[0-4]\\d|[01]?\\d\\d?)\\.){3}(25[0-5]|2[0-4]\\d|[01]?\\d\\d?)$") ;
    if( !rx.exactMatch(ip) ) {
          return false;
    }
    return true;
}

void King_serial::on_pushButton_network_start_clicked()
{
    myNetwork.mode = ui->comboBox_network_mode->currentIndex();
    myNetwork.ip = ui->comboBox_network_ip->currentText();
    myNetwork.port = ui->lineEdit_network_port->text().toUShort();
    myNetwork.udpIP = ui->comboBox_network_udpIp->currentText();
    myNetwork.udpPort = ui->lineEdit_network_udpPort->text().toUShort();
    if(!isIpAddr(myNetwork.ip)) {
        QMessageBox::information(this, tr("错误"), QString("ip地址:%1错误").arg(myNetwork.ip));
        return;
    }
    if(!isIpAddr(myNetwork.udpIP)) {
        QMessageBox::information(this, tr("错误"), QString("ip地址:%1错误").arg(myNetwork.udpIP));
        return;
    }
    if(myNetwork.isOpen == false) {
        switch (myNetwork.mode) {
            case NetMode_TcpServer: {
                myNetwork.isOpen = tcpServer->start();
                if(myNetwork.isOpen) {
                    ui->pushButton_network_start->setText("关闭监听");
                    network_ui_control_setEnanble(false);
                }else {
                    sendInfo(msgType_error, QString("开启监听失败: %1").arg(tcpServer->errorString()), false);
                }
            }break;

            case NetMode_TcpSocket: {
                tcpSocket->connectToHost(myNetwork.ip, myNetwork.port);
            }break;

            case NetMode_UdpServer: {
                myNetwork.isOpen = udpServer->bind(QHostAddress(myNetwork.ip), myNetwork.port);
                if (myNetwork.isOpen) {
                    sendInfo(msgType_network_send, "监听成功", false);
                    ui->pushButton_network_start->setText("关闭监听");
                    network_ui_control_setEnanble(false);
                } else {
                    sendInfo(msgType_error, QString("开启监听失败: %1").arg(tcpServer->errorString()), false);
                }
            }break;

            case NetMode_UdpSocket: {
                myNetwork.isOpen = true;
                ui->pushButton_network_start->setText("断开");
                network_ui_control_setEnanble(false);
                //绑定网卡和端口 采用端口是否一样来判断是为了方便可以直接动态绑定切换端口 没有绑定过才需要绑定
                if (udpSocket->localPort() != myNetwork.ip) {
                    udpSocket->abort();
                    udpSocket->bind(QHostAddress(myNetwork.ip), quint16(myNetwork.port));
                }
            }break;
            default: break;
        }
    } else {
        switch (myNetwork.mode) {
            case NetMode_TcpServer: {
                tcpServer->stop();
                ui->pushButton_network_start->setText("启动监听");
                network_ui_control_setEnanble(true);
            }break;

            case NetMode_TcpSocket: tcpSocket->abort(); break;

            case NetMode_UdpServer: {
                udpServer->abort();
                myNetwork.isOpen = false;
                ui->pushButton_network_start->setText("开启监听");
                network_ui_control_setEnanble(true);
                ui->label_clientList->setText("共 0 个客户端");
            }break;

            case NetMode_UdpSocket: {
                udpSocket->abort();
                myNetwork.isOpen = false;
                ui->pushButton_network_start->setText("连接");
                network_ui_control_setEnanble(true);
            }break;
            default: break;
        }
    }
}

/* ------------------------------ tcp client ------------------------------- */
void King_serial::tcpSocket_connected()
{
    network_ui_control_setEnanble(false);
    ui->pushButton_network_start->setText("关闭服务");
    sendInfo(msgType_network_send, "连接服务器连接", false);
    sendInfo(msgType_network_send, QString("本地地址: %1  本地端口: %2").arg(tcpSocket->localAddress().toString()).arg(tcpSocket->localPort()), false);
    sendInfo(msgType_network_send, QString("远程地址: %1  远程端口: %2").arg(tcpSocket->peerAddress().toString()).arg(tcpSocket->peerPort()), false);
}

void King_serial::tcpSocket_disconnected()
{
    network_ui_control_setEnanble(true);
    ui->pushButton_network_start->setText("启动服务");
    sendInfo(msgType_network_recv, "已从服务器断开", false);
}

void King_serial::tcpSocket_error()
{
    myNetwork.isOpen = false;
    sendInfo(msgType_error, tcpSocket->errorString(), false);
}

void King_serial::tcpSocket_recvData()
{
    QByteArray data = tcpSocket->readAll();
    if (data.length() <= 0) {
        return;
    }
    QString buffer;
    if (ui->checkBox_hex_recv->isChecked()) {
        buffer = api::byteArrayToHexStr(data);
    } else {
        buffer = api::byteArrayToAsciiStr(data);
    }
    modBus_analysisData(buffer);
    sendInfo(msgType_network_recv, buffer, false);
}

/* ------------------------------ tcp server ------------------------------- */
void King_serial::tcpServer_connected(const QString &ip, int port)
{
    QString str = QString("%1:%2").arg(ip).arg(port);
    ui->listWidget_network_clientList->addItem(str);
    ui->label_clientList->setText(QString("共 %1 个客户端").arg(ui->listWidget_network_clientList->count()));
    sendInfo(msgType_network_send, QString("[%1:%2] %3").arg(ip).arg(port).arg("客户端上线"), false);
}

void King_serial::tcpServer_disconnected(const QString &ip, int port)
{
    int row = -1;
    QString str = QString("%1:%2").arg(ip).arg(port);
    for (int i = 0; i < ui->listWidget_network_clientList->count(); i++) {
        if (ui->listWidget_network_clientList->item(i)->text() == str) {
            row = i;
            break;
        }
    }
    delete ui->listWidget_network_clientList->takeItem(row);
    ui->label_clientList->setText(QString("共 %1 个客户端").arg(ui->listWidget_network_clientList->count()));
    sendInfo(msgType_about, QString("[%1:%2] %3").arg(ip).arg(port).arg("客户端下线"), false);
}

void King_serial::tcpServer_error(const QString &ip, int port, const QString &error)
{
    sendInfo(msgType_about, QString("[%1:%2] %3").arg(ip).arg(port).arg(error), false);
}

void King_serial::tcpServer_sendData(const QString &ip, int port, const QString &data)
{
    sendInfo(msgType_network_send, QString("[%1:%2] %3").arg(ip).arg(port).arg(data), false);
}

void King_serial::tcpServer_recvData(const QString &ip, int port, const QString &data)
{
    sendInfo(msgType_network_recv, QString("[%1:%2] %3").arg(ip).arg(port).arg(data), false);
}

/* ------------------------------ udp client ------------------------------- */
void King_serial::udpSocket_recvData()
{
    QHostAddress host;
    quint16 port;
    QByteArray data;
    QString buffer;

    while (udpSocket->hasPendingDatagrams()) {
        data.resize(int(udpSocket->pendingDatagramSize()));
        udpSocket->readDatagram(data.data(), data.size(), &host, &port);

        if (AppConfig::HexReceive) {
            buffer = api::byteArrayToHexStr(data);
        } else {
            buffer = api::byteArrayToAsciiStr(data);
        }
        QString ip = host.toString();
        ip = ip.replace("::ffff:", "");
        if (ip.isEmpty()) {
            continue;
        }
        QString str = QString("[%1:%2] %3").arg(ip).arg(port).arg(buffer);
        sendInfo(msgType_network_recv, str, false);
    }
}

void King_serial::udpSocket_error()
{
    sendInfo(msgType_error, udpSocket->errorString(), false);
}

/* ------------------------------ udp server ------------------------------- */
void King_serial::udpServer_recvData()
{
    QHostAddress host;
    quint16 port;
    QByteArray data;
    QString buffer;

    while (udpServer->hasPendingDatagrams()) {
        data.resize(int(udpServer->pendingDatagramSize()));
        udpServer->readDatagram(data.data(), data.size(), &host, &port);

        if (AppConfig::HexReceive) {
            buffer = api::byteArrayToHexStr(data);
        } else {
            buffer = api::byteArrayToAsciiStr(data);
        }

        QString ip = host.toString();
        ip = ip.replace("::ffff:", "");
        if (ip.isEmpty()) {
            continue;
        }

        QString str = QString("[%1:%2] %3").arg(ip).arg(port).arg(buffer);
        sendInfo(msgType_network_recv, str, false);

        //先过滤重复的
        str = QString("%1:%2").arg(ip).arg(port);
        for (int i = 0; i < ui->listWidget_network_clientList->count(); i++) {
            QString s = ui->listWidget_network_clientList->item(i)->text();
            if (str == s) {
                return;
            }
        }
        //添加到列表
        ui->listWidget_network_clientList->addItem(str);
        ui->label_clientList->setText(QString("共 %1 个客户端").arg(ui->listWidget_network_clientList->count()));
    }
}

void King_serial::udpServer_error()
{
    sendInfo(msgType_error, udpServer->errorString(), false);
}

/* ------------------------------------------------- ModBus部分 ----------------------------------------------- */
/* ------------------------------------------------- ModBus部分 ----------------------------------------------- */
/* ------------------------------------------------- ModBus部分 ----------------------------------------------- */
void King_serial::ModBus_config()
{
    // 1.Modbus初始化
    ModBus_ui_control_setEnanble(false);
    // 2.重写控件内容
    ui->comboBox_modBus_mode->setCurrentIndex(ui->comboBox_modBus_mode->findText(AppConfig::ModBusProtocol));
    ui->comboBox_modBus_readFormat->setCurrentIndex(ui->comboBox_modBus_readFormat->findText(AppConfig::ModBusReadFormat));
    ui->comboBox_modBus_byteEndian->setCurrentIndex(ui->comboBox_modBus_byteEndian->findText(AppConfig::ModBusByteEndian));
    ui->lineEdit_modBus_slaveAddr->setText(AppConfig::ModBusSlaveAddr);
    ui->lineEdit_modBus_funcCode->setText(AppConfig::ModBusFuncCode);
    ui->lineEdit_modBus_readAddr->setText(AppConfig::ModBusReadAddr);
    ui->lineEdit_modBus_readLength->setText(AppConfig::ModBusReadLen);
    // 3.绑定槽函数
    connect(ui->comboBox_modBus_mode, SIGNAL(currentIndexChanged(int)), this, SLOT(saveConfig()));
    connect(ui->comboBox_modBus_readFormat, SIGNAL(currentIndexChanged(int)), this, SLOT(saveConfig()));
    connect(ui->comboBox_modBus_byteEndian, SIGNAL(currentIndexChanged(int)), this, SLOT(saveConfig()));
    connect(ui->lineEdit_modBus_slaveAddr, SIGNAL(textChanged(QString)), this, SLOT(saveConfig()));
    connect(ui->lineEdit_modBus_funcCode, SIGNAL(textChanged(QString)), this, SLOT(saveConfig()));
    connect(ui->lineEdit_modBus_readAddr, SIGNAL(textChanged(QString)), this, SLOT(saveConfig()));
    connect(ui->lineEdit_modBus_readLength, SIGNAL(textChanged(QString)), this, SLOT(saveConfig()));
    // 4.设置tableWieght属性
    //ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch); // 设置表格等宽
    ui->tableWidget->horizontalHeader()->setStretchLastSection(true); // 设置表格充满 行末不留空
    ui->tableWidget->setRowCount(TABEL_RAW);// 设置最大8行
    ui->tableWidget->setColumnCount(2);     // 初始设置2列
    ui->tableWidget->setStyleSheet("selection-background-color:rgb(72, 202, 245);"); // 设置选中行的背景色
    ui->tableWidget->horizontalHeader()->setStyleSheet("QHeaderView::section{background:skyblue;}"); // 设置表头的背景色
    ReadOnlyDelegate* readOnlyDelegate = new ReadOnlyDelegate(this);
    ui->tableWidget->setItemDelegateForColumn(1, readOnlyDelegate);   // 设置 第1列(数据)只读
}

QWidget *ReadOnlyDelegate::createEditor(QWidget *parent, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
    Q_UNUSED(parent)
    Q_UNUSED(option)
    Q_UNUSED(index)
    return nullptr;
}

void King_serial::ModBus_ui_control_setEnanble(bool state)
{
    myModBus.isOpen = state;
    ui->comboBox_modBus_mode->setEnabled(state);
    ui->comboBox_modBus_readFormat->setEnabled(state);
    ui->comboBox_modBus_byteEndian->setEnabled(state);
    ui->lineEdit_modBus_slaveAddr->setEnabled(state);
    ui->lineEdit_modBus_funcCode->setEnabled(state);
    ui->lineEdit_modBus_readAddr->setEnabled(state);
    ui->lineEdit_modBus_readLength->setEnabled(state);
    ui->pushButton_modBus_send->setEnabled(state);
    ui->tableWidget->setEnabled(state);
    on_comboBox_modBus_mode_currentIndexChanged(0);
}

void King_serial::on_pushButton_modBus_open_clicked()
{
    if(!myModBus.isOpen) {
        ui->pushButton_modBus_open->setText("关闭传输");
        ModBus_ui_control_setEnanble(true);
    } else {
        ui->pushButton_modBus_open->setText("启动传输");
        ModBus_ui_control_setEnanble(false);
    }
}

void King_serial::on_lineEdit_modBus_readAddr_textChanged(const QString &arg1)
{
    QString uStr = arg1;
    uStr.remove(" "); // 移除空格

    if (uStr.length() > 3 && uStr.length() % 2 == 0) {
       QString uStr2, uStr3;
       for (int i = 0; i < (uStr.length() / 2 - 1); i++) {
           uStr2 = uStr.mid(i * 2, 2);  // 取子串
           uStr3 += uStr2 + " ";        // 加空格
       }
       uStr2 = uStr.mid(uStr.length() - 2, 2); // 加上后面的
       uStr3 += uStr2;

       ui->lineEdit_modBus_readAddr->setText(uStr3);
    }
}

void King_serial::on_pushButton_modBus_send_clicked()
{
    QString frameData;
    static quint16 tran_id = 0; // 报文的序列号

    // 1.获取需要转发的协议数据
    myModBus.slaveAddr = ui->lineEdit_modBus_slaveAddr->text().toLocal8Bit();
    myModBus.FuncCode = ui->lineEdit_modBus_funcCode->text().toLocal8Bit();
    myModBus.DataAddr = ui->lineEdit_modBus_readAddr->text().toLocal8Bit();
    myModBus.DataLen = quint16(ui->lineEdit_modBus_readLength->text().toLocal8Bit().toUInt());
    switch (ui->comboBox_modBus_mode->currentIndex()) {
        case ModBus_ASCII: {
            if(!mySerial.isOpen) {
                QMessageBox::warning(this, "Warning", "串口未打开，请打开串口后重试!");
                return;
            }
            frameData.append(myModBus.slaveAddr);
            frameData.append(myModBus.FuncCode);
            frameData.append(myModBus.DataAddr);
            frameData.append(QString("%1 %2").arg(myModBus.DataLen>>8, 2, 16, QLatin1Char('0')).toUpper()
                                             .arg(myModBus.DataLen   , 2, 16, QLatin1Char('0')).toUpper());
            frameData.remove(" ");// 移除空格
            // 2.追加LRC校验
            quint8 lrc = api::ModBusLRC(QByteArray::fromHex(frameData.toLocal8Bit()));
            // 3.校验完后添加帧头
            frameData.prepend(":");
            // 4.追加LRC校验和帧尾
            frameData.append(QString("%1\r\n").arg(lrc, 2, 16, QLatin1Char('0')).toUpper());
            sendBuff(frameData);
        }break;

        case ModBus_RTU: {
            if(!mySerial.isOpen) {
                QMessageBox::warning(this, "Warning", "串口未打开，请打开串口后重试!");
                return;
            }
            // 2.向帧数据中追加内容
            frameData.append(myModBus.slaveAddr);
            frameData.append(myModBus.FuncCode);
            frameData.append(myModBus.DataAddr);
            frameData.append(QString("%1 %2").arg(myModBus.DataLen>>8, 2, 16, QLatin1Char('0')).toUpper()
                                             .arg(myModBus.DataLen   , 2, 16, QLatin1Char('0')).toUpper());
            frameData.remove(" ");// 移除空格
            qDebug() <<frameData <<myModBus.FuncCode;
            // 3.对数据做CRC16校验
            myModBus.CRC16 = api::ModbusCRC16(QByteArray::fromHex(frameData.toLocal8Bit()));
            // 4.将CRC16校验转换成大端字节序
            myModBus.CRC16 = qFromBigEndian<quint16>(myModBus.CRC16);
            // 5.校验位Hex默认补0
            QString crc16 = QString("%1").arg(myModBus.CRC16, 4, 16, QLatin1Char('0')).toUpper();
            // 6.向帧数据中追加校验位
            frameData.append(crc16);
            sendBuff(frameData);
        }break;

        case ModBus_TCP: {
            if(!myNetwork.isOpen) {
                QMessageBox::warning(this, "Warning", "服务端未连接，请连接服务端后重试!");
                return;
            }
            myModBus.Transaction_ID = QString("%1 %2").arg(tran_id>>8, 2, 16, QLatin1Char('0')).toUpper()
                                                      .arg(tran_id, 2, 16, QLatin1Char('0')).toUpper();
            myModBus.Protocol_ID = "00 00"; // 标识 ModBus TCP协议
            myModBus.NextLen = "00 06";     // 报头之后的长度
            tran_id += 1;                   // 每次通信后需要自加1
            frameData.append(myModBus.Transaction_ID);
            frameData.append(myModBus.Protocol_ID);
            frameData.append(myModBus.NextLen);
            frameData.append(myModBus.slaveAddr);
            frameData.append(myModBus.FuncCode);
            frameData.append(myModBus.DataAddr);
            frameData.append(QString("%1 %2").arg(myModBus.DataLen>>8, 2, 16, QLatin1Char('0')).toUpper()
                                             .arg(myModBus.DataLen   , 2, 16, QLatin1Char('0')).toUpper());
            frameData.remove(" ");// 移除空格
            sendBuff(frameData);
         }break;
    }
}

void King_serial::modBus_analysisData(QString data)
{
    static QString buffer;
    if(myModBus.isOpen) {
        buffer += data;
        switch (ui->comboBox_modBus_mode->currentIndex()) {
            case ModBus_ASCII: {
                if(buffer.startsWith(":") && buffer.endsWith("\r\n")) {
                    int datLen = api::strHexToDecimal(buffer.mid(5, 2));
                    QString dat = buffer.mid(7, datLen*2);
                    QStringList datList;
                    for(int i=0; i<datLen*2; i+=2) {
                        datList <<dat.mid(i, 2);
                    }
                    modBus_serialMode_analysisData(datList);
                    buffer.clear();
                }
            }break;
            case ModBus_RTU: {
                if(buffer.startsWith(myModBus.slaveAddr) && buffer.contains(myModBus.FuncCode)) {
                    int datLen = api::strHexToDecimal(buffer.mid(6, 2));
                    QString dat = buffer.mid(9, datLen*3-1); // 10=Hex空格(1)+从机地址(2)+Hex空格(1)+功能码(2)+Hex空格(1)+数据长度(2)+Hex空格(1)
                    QStringList datList = dat.split(" ");   // 解析数据长度的列表
                    modBus_serialMode_analysisData(datList);
                    buffer.clear();
                }
            }break;
            case ModBus_TCP: {
                if(buffer.startsWith(myModBus.Transaction_ID) && buffer.contains(myModBus.FuncCode)) {
                    int datLen = api::strHexToDecimal(buffer.mid(24, 2));
                    QString dat = buffer.mid(27, datLen*3-1);
                    QStringList datList = dat.split(" ");   // 解析数据长度的列表
                    modBus_serialMode_analysisData(datList);
                    buffer.clear();
                }
            }break;
        }
    }
}

void King_serial::modBus_serialMode_analysisData(QStringList datList)
{
    QString temp;   // 数据缓存
    qint64 dat64_H, dat64_L; // 定义两个64位字节用于计算64位数据的值
    QStringList header;
    int datList_len = datList.size();
    int readLen = myModBus.DataLen;// 想要读取字节长度的列表

    switch (ui->comboBox_modBus_readFormat->currentIndex()) {
        case ModBus_Format_Signed:
        case ModBus_Format_Unsigned: {
            // 动态设置表头和表头内容
            int tableColumn = (datList_len/(TABEL_RAW*2)+1)*2;
            ui->tableWidget->setColumnCount(tableColumn);// 设置列数
            for(int i=0; i<tableColumn; i+=2) {
                header <<"Note" <<QString("Offset(%1)").arg(i/2*TABEL_RAW);
            }
            ui->tableWidget->setHorizontalHeaderLabels(header);
            for(int i=0; i<tableColumn; i+=2) {
                for(int j=i*TABEL_RAW; j<(i+2)*TABEL_RAW; j+=2) {
                    if(j < datList_len) {
                        temp = QString("%1").arg((api::strHexToDecimal(datList[j])<<8) | api::strHexToDecimal(datList[j+1]));
                    } else {
                        temp = QString("0");
                    }
                    QTableWidgetItem *item = new QTableWidgetItem(temp);
                    item->setTextAlignment(Qt::AlignCenter); // 设置文本居中
                    ui->tableWidget->setItem((j-i*TABEL_RAW)/2, i+1, item);
                    ui->tableWidget->clearSpans();// 拆分单元格
                    ReadOnlyDelegate* readOnlyDelegate = new ReadOnlyDelegate(this);
                    ui->tableWidget->setItemDelegateForColumn(i+1, readOnlyDelegate);   // 设置 (数据)只读
                }
            }
        }break;
        case ModBus_Format_Hex: {
            // 动态设置表头和表头内容
            int tableColumn = (datList_len/(TABEL_RAW*2)+1)*2;
            ui->tableWidget->setColumnCount(tableColumn);// 设置列数
            for(int i=0; i<tableColumn; i+=2) {
                header <<"Note" <<QString("Offset(%1)").arg(i/2*TABEL_RAW);
            }
            ui->tableWidget->setHorizontalHeaderLabels(header);
            for(int i=0; i<tableColumn; i+=2) {
                for(int j=i*TABEL_RAW; j<(i+2)*TABEL_RAW; j+=2) {
                    if(j < datList_len) {
                        temp = QString("0x%1%2").arg(datList[j]).arg(datList[j+1]);
                    } else {
                       temp = QString("0");
                   }
                   QTableWidgetItem *item = new QTableWidgetItem(temp);
                   item->setTextAlignment(Qt::AlignCenter); // 设置文本居中
                   ui->tableWidget->setItem((j-i*TABEL_RAW)/2, i+1, item);
                   ui->tableWidget->clearSpans();// 拆分单元格
                   ReadOnlyDelegate* readOnlyDelegate = new ReadOnlyDelegate(this);
                   ui->tableWidget->setItemDelegateForColumn(i+1, readOnlyDelegate);   // 设置 (数据)只读
                }
            }
        }break;
        case ModBus_Format_Binary: {
            // 动态设置表头和表头内容
            int tableColumn = (datList_len/(TABEL_RAW*2)+1)*2;
            ui->tableWidget->setColumnCount(tableColumn);// 设置列数
            for(int i=0; i<tableColumn; i+=2) {
                header <<"Note" <<QString("Offset(%1)").arg(i/2*TABEL_RAW);
            }
            ui->tableWidget->setHorizontalHeaderLabels(header);
            for(int i=0; i<tableColumn; i+=2) {
                for(int j=i*TABEL_RAW; j<(i+2)*TABEL_RAW; j+=2) {
                    if(j < datList_len) {
                    temp = QString("%1%2").arg(api::strHexToStrBin(datList[j])).arg(api::strHexToStrBin(datList[j+1]));
                } else {
                   temp = QString("0");
               }
               QTableWidgetItem *item = new QTableWidgetItem(temp);
               item->setTextAlignment(Qt::AlignCenter); // 设置文本居中
               ui->tableWidget->setItem((j-i*TABEL_RAW)/2, i+1, item);
               ui->tableWidget->clearSpans();// 拆分单元格
               ReadOnlyDelegate* readOnlyDelegate = new ReadOnlyDelegate(this);
               ui->tableWidget->setItemDelegateForColumn(i+1, readOnlyDelegate);   // 设置 (数据)只读
            }
        }
        }break;
        case ModBus_Format_32BitSigned:
        case ModBus_Format_32BitUnsigned: {
            if(readLen%2 != 0) {
                QMessageBox::warning(this, "Warning", "数据长度错误，请检查数据格式...\r\n一个32位数据需要2个数据长度");
                return;
            }
            // 动态设置表头和表头内容
            int tableColumn = (datList_len/(TABEL_RAW*2)+1)*2;
            ui->tableWidget->setColumnCount(tableColumn);// 设置列数
            for(int i=0; i<tableColumn; i+=2) {
                header <<"Note" <<QString("Offset(%1)").arg(i/2*TABEL_RAW);
            }
            ui->tableWidget->setHorizontalHeaderLabels(header);
            for(int i=0; i<tableColumn; i+=2) {
                for(int j=i*TABEL_RAW; j<(i+2)*TABEL_RAW; j+=4) {
                    if(j < datList_len) {
                        switch (ui->comboBox_modBus_byteEndian->currentIndex()) {
                            case ModBusEndian_Big: {
                                temp = QString("%1").arg((api::strHexToDecimal(datList[j+0])<<24) |
                                                         (api::strHexToDecimal(datList[j+1])<<16) |
                                                         (api::strHexToDecimal(datList[j+2])<<8)  |
                                                         (api::strHexToDecimal(datList[j+3])));
                            }break;
                            case ModBusEndian_Little: {
                                temp = QString("%1").arg((api::strHexToDecimal(datList[j+3])<<24) |
                                                         (api::strHexToDecimal(datList[j+2])<<16) |
                                                         (api::strHexToDecimal(datList[j+1])<<8)  |
                                                         (api::strHexToDecimal(datList[j+0])));
                            }break;
                            case ModBusEndian_BigSwap: {
                                temp = QString("%1").arg((api::strHexToDecimal(datList[j+1])<<24) |
                                                         (api::strHexToDecimal(datList[j+0])<<16) |
                                                         (api::strHexToDecimal(datList[j+3])<<8)  |
                                                         (api::strHexToDecimal(datList[j+2])));
                            }break;
                            case ModBusEndian_LittleSwap: {
                                temp = QString("%1").arg((api::strHexToDecimal(datList[j+2])<<24) |
                                                         (api::strHexToDecimal(datList[j+3])<<16) |
                                                         (api::strHexToDecimal(datList[j+0])<<8)  |
                                                         (api::strHexToDecimal(datList[j+1])));
                            }break;
                        }
                    } else {
                        temp = QString("0");
                    }
                    QTableWidgetItem *item = new QTableWidgetItem(temp);
                    item->setTextAlignment(Qt::AlignCenter);    // 设置文本居中
                    int row = (j-i*TABEL_RAW)/2;
                    int culomn = i+1;
                    ui->tableWidget->setItem(row, culomn, item);// 设置数据
                    ui->tableWidget->setSpan(row, culomn-1, 2, 1);// 合并单元格
                    ui->tableWidget->setSpan(row, culomn, 2, 1);// 合并单元格
                    ReadOnlyDelegate* readOnlyDelegate = new ReadOnlyDelegate(this);
                    ui->tableWidget->setItemDelegateForColumn(culomn, readOnlyDelegate);   // 设置 (数据)只读
                }
            }
        }break;
        case ModBus_Format_Float: {
            if(readLen%2 != 0) {
                QMessageBox::warning(this, "Warning", "数据长度错误，请检查数据格式...\r\n一个浮点型数据需要2个数据长度");
                return;
            }
            union_FloatConvert_typedef union_float;
            // 动态设置表头和表头内容
            int tableColumn = (datList_len/(TABEL_RAW*2)+1)*2;
            ui->tableWidget->setColumnCount(tableColumn);// 设置列数
            for(int i=0; i<tableColumn; i+=2) {
                header <<"Note" <<QString("Offset(%1)").arg(i/2*TABEL_RAW);
            }
            ui->tableWidget->setHorizontalHeaderLabels(header);

            for(int i=0; i<tableColumn; i+=2) {
                for(int j=i*TABEL_RAW; j<(i+2)*TABEL_RAW; j+=4) {
                    if(j < datList_len) {
                        switch (ui->comboBox_modBus_byteEndian->currentIndex()) {
                            case ModBusEndian_Big: {
                                // 将QString转成Hex
                                union_float.buf[3] = static_cast<uint8_t>(datList[j+0].toUInt(nullptr, 16));
                                union_float.buf[2] = static_cast<uint8_t>(datList[j+1].toUInt(nullptr, 16));
                                union_float.buf[1] = static_cast<uint8_t>(datList[j+2].toUInt(nullptr, 16));
                                union_float.buf[0] = static_cast<uint8_t>(datList[j+3].toUInt(nullptr, 16));
                            }break;
                            case ModBusEndian_Little: {
                                union_float.buf[0] = static_cast<uint8_t>(datList[j+0].toUInt(nullptr, 16));
                                union_float.buf[1] = static_cast<uint8_t>(datList[j+1].toUInt(nullptr, 16));
                                union_float.buf[2] = static_cast<uint8_t>(datList[j+2].toUInt(nullptr, 16));
                                union_float.buf[3] = static_cast<uint8_t>(datList[j+3].toUInt(nullptr, 16));
                            }break;
                            case ModBusEndian_BigSwap: {
                                union_float.buf[3] = static_cast<uint8_t>(datList[j+0].toUInt(nullptr, 16));
                                union_float.buf[2] = static_cast<uint8_t>(datList[j+1].toUInt(nullptr, 16));
                                union_float.buf[0] = static_cast<uint8_t>(datList[j+2].toUInt(nullptr, 16));
                                union_float.buf[1] = static_cast<uint8_t>(datList[j+3].toUInt(nullptr, 16));
                            }break;
                            case ModBusEndian_LittleSwap: {
                                union_float.buf[1] = static_cast<uint8_t>(datList[j+0].toUInt(nullptr, 16));
                                union_float.buf[0] = static_cast<uint8_t>(datList[j+1].toUInt(nullptr, 16));
                                union_float.buf[3] = static_cast<uint8_t>(datList[j+2].toUInt(nullptr, 16));
                                union_float.buf[2] = static_cast<uint8_t>(datList[j+3].toUInt(nullptr, 16));
                            }break;
                        }
                        temp = QString("%1").arg(double(union_float.F));
                    } else {
                        temp = QString("0");
                    }

                    QTableWidgetItem *item = new QTableWidgetItem(temp);
                    item->setTextAlignment(Qt::AlignCenter);    // 设置文本居中
                    int row = (j-i*TABEL_RAW)/2;
                    int culomn = i+1;
                    ui->tableWidget->setItem(row, culomn, item);// 设置数据
                    ui->tableWidget->setSpan(row, culomn-1, 2, 1);// 合并单元格
                    ui->tableWidget->setSpan(row, culomn, 2, 1);// 合并单元格
                    ReadOnlyDelegate* readOnlyDelegate = new ReadOnlyDelegate(this);
                    ui->tableWidget->setItemDelegateForColumn(culomn, readOnlyDelegate);   // 设置 (数据)只读
                }
            }
        }break;

        case ModBus_Format_64BitSigned:
        case ModBus_Format_64BitUnsigned: {
            if(readLen%4 != 0) {
                QMessageBox::warning(this, "Warning", "数据长度错误，请检查数据格式...\r\n一个64位数据需要4个数据长度");
                return;
            }
            // 动态设置表头和表头内容
            int tableColumn = (datList_len/(TABEL_RAW*3)+1)*2;
            ui->tableWidget->setColumnCount(tableColumn);// 设置列数
            for(int i=0; i<tableColumn; i+=2) {
                header <<"Note" <<QString("Offset(%1)").arg(i/2*TABEL_RAW);
            }
            ui->tableWidget->setHorizontalHeaderLabels(header);
            for(int i=0; i<tableColumn; i+=2) {
                for(int j=i*TABEL_RAW; j<(i+2)*TABEL_RAW; j+=8) {
                    if(j < datList_len) {
                        switch (ui->comboBox_modBus_byteEndian->currentIndex()) {
                            case ModBusEndian_Big: {
                                dat64_H = (api::strHexToDecimal(datList[j+0])<<24) |
                                          (api::strHexToDecimal(datList[j+1])<<16) |
                                          (api::strHexToDecimal(datList[j+2])<<8)  |
                                          (api::strHexToDecimal(datList[j+3])<<0);
                                dat64_L = (api::strHexToDecimal(datList[j+4])<<24) |
                                          (api::strHexToDecimal(datList[j+5])<<16) |
                                          (api::strHexToDecimal(datList[j+6])<<8)  |
                                          (api::strHexToDecimal(datList[j+7])<<0);
                                temp = QString("%1").arg(dat64_H<<32 | dat64_L);
                            }break;
                            case ModBusEndian_Little: {
                                dat64_H = (api::strHexToDecimal(datList[j+7])<<24) |
                                          (api::strHexToDecimal(datList[j+6])<<16) |
                                          (api::strHexToDecimal(datList[j+5])<<8)  |
                                          (api::strHexToDecimal(datList[j+4])<<0);
                                dat64_L = (api::strHexToDecimal(datList[j+3])<<24) |
                                          (api::strHexToDecimal(datList[j+2])<<16) |
                                          (api::strHexToDecimal(datList[j+1])<<8)  |
                                          (api::strHexToDecimal(datList[j+0])<<0);
                                temp = QString("%1").arg(dat64_H<<32 | dat64_L);
                            }break;
                            case ModBusEndian_BigSwap: {
                                dat64_H = (api::strHexToDecimal(datList[j+1])<<24) |
                                          (api::strHexToDecimal(datList[j+0])<<16) |
                                          (api::strHexToDecimal(datList[j+3])<<8)  |
                                          (api::strHexToDecimal(datList[j+2])<<0);
                                dat64_L = (api::strHexToDecimal(datList[j+5])<<24) |
                                          (api::strHexToDecimal(datList[j+4])<<16) |
                                          (api::strHexToDecimal(datList[j+7])<<8)  |
                                          (api::strHexToDecimal(datList[j+6])<<0);
                                temp = QString("%1").arg(dat64_H<<32 | dat64_L);
                            }break;
                            case ModBusEndian_LittleSwap: {
                                dat64_H = (api::strHexToDecimal(datList[j+6])<<24) |
                                          (api::strHexToDecimal(datList[j+7])<<16) |
                                          (api::strHexToDecimal(datList[j+4])<<8)  |
                                          (api::strHexToDecimal(datList[j+5])<<0);
                                dat64_L = (api::strHexToDecimal(datList[j+2])<<24) |
                                          (api::strHexToDecimal(datList[j+3])<<16) |
                                          (api::strHexToDecimal(datList[j+0])<<8)  |
                                          (api::strHexToDecimal(datList[j+1])<<0);
                                temp = QString("%1").arg(dat64_H<<32 | dat64_L);
                            }break;
                        }
                    } else {
                        temp = QString("0");
                    }
                    QTableWidgetItem *item = new QTableWidgetItem(temp);
                    item->setTextAlignment(Qt::AlignCenter);    // 设置文本居中
                    int row = (j-i*TABEL_RAW)/2;
                    int culomn = i+1;
                    ui->tableWidget->setItem(row, culomn, item);// 设置数据
                    ui->tableWidget->setSpan(row, culomn-1, 4, 1);// 合并单元格
                    ui->tableWidget->setSpan(row, culomn, 4, 1);// 合并单元格
                    ReadOnlyDelegate* readOnlyDelegate = new ReadOnlyDelegate(this);
                    ui->tableWidget->setItemDelegateForColumn(culomn, readOnlyDelegate);   // 设置 (数据)只读
                }
            }
        }break;

        case ModBus_Format_Double: {
            if(readLen%4 != 0) {
                QMessageBox::warning(this, "Warning", "数据长度错误，请检查数据格式...\r\n一个浮点型数据需要4个数据长度");
                return;
            }
            // 动态设置表头和表头内容
            int tableColumn = (datList_len/(TABEL_RAW*3)+1)*2;
            ui->tableWidget->setColumnCount(tableColumn);// 设置列数
            for(int i=0; i<tableColumn; i+=2) {
                header <<"Note" <<QString("Offset(%1)").arg(i/2*TABEL_RAW);
            }
            ui->tableWidget->setHorizontalHeaderLabels(header);
            union_DoubleConvert_typedef union_double;
            for(int i=0; i<tableColumn; i+=2) {
                for(int j=i*TABEL_RAW; j<(i+2)*TABEL_RAW; j+=8) {
                    if(j < datList_len) {
                        switch (ui->comboBox_modBus_byteEndian->currentIndex()) {
                            case ModBusEndian_Big: {
                                // 将QString转成Hex
                                union_double.buf[7] = static_cast<uint8_t>(datList[j+0].toUInt(nullptr, 16));
                                union_double.buf[6] = static_cast<uint8_t>(datList[j+1].toUInt(nullptr, 16));
                                union_double.buf[5] = static_cast<uint8_t>(datList[j+2].toUInt(nullptr, 16));
                                union_double.buf[4] = static_cast<uint8_t>(datList[j+3].toUInt(nullptr, 16));
                                union_double.buf[3] = static_cast<uint8_t>(datList[j+4].toUInt(nullptr, 16));
                                union_double.buf[2] = static_cast<uint8_t>(datList[j+5].toUInt(nullptr, 16));
                                union_double.buf[1] = static_cast<uint8_t>(datList[j+6].toUInt(nullptr, 16));
                                union_double.buf[0] = static_cast<uint8_t>(datList[j+7].toUInt(nullptr, 16));
                            }break;
                            case ModBusEndian_Little: {
                                union_double.buf[0] = static_cast<uint8_t>(datList[j+0].toUInt(nullptr, 16));
                                union_double.buf[1] = static_cast<uint8_t>(datList[j+1].toUInt(nullptr, 16));
                                union_double.buf[2] = static_cast<uint8_t>(datList[j+2].toUInt(nullptr, 16));
                                union_double.buf[3] = static_cast<uint8_t>(datList[j+3].toUInt(nullptr, 16));
                                union_double.buf[4] = static_cast<uint8_t>(datList[j+4].toUInt(nullptr, 16));
                                union_double.buf[5] = static_cast<uint8_t>(datList[j+5].toUInt(nullptr, 16));
                                union_double.buf[6] = static_cast<uint8_t>(datList[j+6].toUInt(nullptr, 16));
                                union_double.buf[7] = static_cast<uint8_t>(datList[j+7].toUInt(nullptr, 16));
                            }break;
                            case ModBusEndian_BigSwap: {
                                union_double.buf[6] = static_cast<uint8_t>(datList[j+0].toUInt(nullptr, 16));
                                union_double.buf[7] = static_cast<uint8_t>(datList[j+1].toUInt(nullptr, 16));
                                union_double.buf[4] = static_cast<uint8_t>(datList[j+2].toUInt(nullptr, 16));
                                union_double.buf[5] = static_cast<uint8_t>(datList[j+3].toUInt(nullptr, 16));
                                union_double.buf[3] = static_cast<uint8_t>(datList[j+4].toUInt(nullptr, 16));
                                union_double.buf[2] = static_cast<uint8_t>(datList[j+5].toUInt(nullptr, 16));
                                union_double.buf[0] = static_cast<uint8_t>(datList[j+6].toUInt(nullptr, 16));
                                union_double.buf[1] = static_cast<uint8_t>(datList[j+7].toUInt(nullptr, 16));
                            }break;
                            case ModBusEndian_LittleSwap: {
                                union_double.buf[1] = static_cast<uint8_t>(datList[j+0].toUInt(nullptr, 16));
                                union_double.buf[0] = static_cast<uint8_t>(datList[j+1].toUInt(nullptr, 16));
                                union_double.buf[3] = static_cast<uint8_t>(datList[j+2].toUInt(nullptr, 16));
                                union_double.buf[2] = static_cast<uint8_t>(datList[j+3].toUInt(nullptr, 16));
                                union_double.buf[5] = static_cast<uint8_t>(datList[j+4].toUInt(nullptr, 16));
                                union_double.buf[4] = static_cast<uint8_t>(datList[j+5].toUInt(nullptr, 16));
                                union_double.buf[7] = static_cast<uint8_t>(datList[j+6].toUInt(nullptr, 16));
                                union_double.buf[6] = static_cast<uint8_t>(datList[j+7].toUInt(nullptr, 16));
                            }break;
                        }
                        temp = QString("%1").arg(double(union_double.D));
                    } else {
                        temp = QString("0");
                    }
                    QTableWidgetItem *item = new QTableWidgetItem(temp);
                    item->setTextAlignment(Qt::AlignCenter);    // 设置文本居中
                    int row = (j-i*TABEL_RAW)/2;
                    int culomn = i+1;
                    ui->tableWidget->setItem(row, culomn, item);// 设置数据
                    ui->tableWidget->setSpan(row, culomn-1, 4, 1);// 合并单元格
                    ui->tableWidget->setSpan(row, culomn, 4, 1);// 合并单元格
                    ReadOnlyDelegate* readOnlyDelegate = new ReadOnlyDelegate(this);
                    ui->tableWidget->setItemDelegateForColumn(culomn, readOnlyDelegate);   // 设置 (数据)只读
                }
            }
        }break;
    }
}

void King_serial::on_comboBox_modBus_mode_currentIndexChanged(int index)
{
    Q_UNUSED(index);
    if(myModBus.isOpen) {
        switch (ui->comboBox_modBus_mode->currentIndex()) {
            case ModBus_ASCII: {
                ui->checkBox_hex_send->setChecked(false);
                ui->checkBox_hex_recv->setChecked(false);
                ui->checkBox_autoReturn->setChecked(true);
                ui->checkBox_hex_send->setEnabled(true);
                ui->checkBox_hex_recv->setEnabled(true);
                ui->checkBox_autoReturn->setEnabled(true);
            }break;
            case ModBus_RTU: {
                ui->checkBox_hex_send->setChecked(true);
                ui->checkBox_hex_recv->setChecked(true);
                ui->checkBox_autoReturn->setChecked(false);
                ui->checkBox_hex_send->setEnabled(false);
                ui->checkBox_hex_recv->setEnabled(false);
                ui->checkBox_autoReturn->setEnabled(false);
            }break;
            case ModBus_TCP: {
                ui->checkBox_hex_send->setChecked(true);
                ui->checkBox_hex_recv->setChecked(true);
                ui->checkBox_hex_send->setEnabled(false);
                ui->checkBox_hex_recv->setEnabled(false);
            }break;
        }
    } else {
        ui->checkBox_hex_send->setEnabled(true);
        ui->checkBox_hex_recv->setEnabled(true);
        ui->checkBox_autoReturn->setEnabled(true);
    }
}
