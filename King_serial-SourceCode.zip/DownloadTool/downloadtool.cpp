// 使用开源库实现 http下载 参考博客：https://zhuanlan.zhihu.com/p/549021090

#include "DownloadTool/downloadtool.h"

downloadTool::downloadTool(const QString& downloadUrl, const QString& savePath, QObject* parent)
    : QObject(parent)
{
    m_downloadUrl = downloadUrl;
    m_savePath    = savePath;
}

downloadTool::~downloadTool() {}

void downloadTool::startDownload()
{
    const QUrl newUrl = QUrl::fromUserInput(m_downloadUrl);

    if (!newUrl.isValid()) {
#if (DOWNLOAD_DEBUG == 1)
        qDebug() << QString("Invalid URL: %1: %2").arg(m_downloadUrl, newUrl.errorString());
#endif
        return;
    }

    QString fileName = newUrl.fileName();
    qDebug() <<fileName;
    if (fileName.isEmpty() || fileName != "update.json") {
        fileName = defaultFileName;
    }
    if (m_savePath.isEmpty()) {
        m_savePath = QApplication::applicationDirPath() + "/download";
    }
    if (!QFileInfo(m_savePath).isDir()) {
        QDir dir;
        dir.mkpath(m_savePath);
    }
    fileName.prepend(m_savePath + '/');
    if (QFile::exists(fileName)) {
        QFile::remove(fileName);
    }
    file = openFileForWrite(fileName);
    if (!file) return;

    startRequest(newUrl);
}

void downloadTool::cancelDownload()
{
    httpRequestAborted = true;
    reply->abort();
}

void downloadTool::startRequest(const QUrl& requestedUrl)
{
    url = requestedUrl;
    httpRequestAborted = false;

    // 发送https请求前准备工作
    QNetworkRequest request;
    request.setUrl(url);
    QSslConfiguration config;
    QSslConfiguration conf = request.sslConfiguration();
    conf.setPeerVerifyMode(QSslSocket::VerifyNone);
    conf.setProtocol(QSsl::TlsV1SslV3);
    request.setSslConfiguration(conf);

    reply = netManager.get(request);
    reply = netManager.get(QNetworkRequest(url));

    connect(reply, SIGNAL(finished()), this, SLOT(on_http_finished()));
    connect(reply, SIGNAL(readyRead()), this, SLOT(on_http_readyRead()));
    connect(reply, SIGNAL(error(QNetworkReply::NetworkError)) , this , SLOT(on_http_error(QNetworkReply::NetworkError)));
    connect(reply, SIGNAL(downloadProgress(qint64, qint64)), this, SLOT(networkReplyProgress(qint64, qint64)));

#if (DOWNLOAD_DEBUG == 1)
    qDebug() << QString(tr("Downloading %1").arg(url.toString()));
#endif
}

void downloadTool::on_http_finished()
{
    QFileInfo fileInfo;
    if (file) {
        fileInfo.setFile(file->fileName());
        file->close();
        file.reset();
    }
    if (httpRequestAborted) {
        return;
    }

    if (reply->error() != QNetworkReply::NoError) {
        QFile::remove(fileInfo.absoluteFilePath());
        emit download_failed();
#if (DOWNLOAD_DEBUG == 1)
        qDebug() << QString("Download failed: %1.").arg(reply->errorString());
#endif
        return;
    }

    const QVariant redirectionTarget = reply->attribute(QNetworkRequest::RedirectionTargetAttribute);

    if (!redirectionTarget.isNull()) {
        const QUrl redirectedUrl = url.resolved(redirectionTarget.toUrl());
        file = openFileForWrite(fileInfo.absoluteFilePath());
        if (!file) {
            return;
        }
        startRequest(redirectedUrl);
        return;
    }
#if (DOWNLOAD_DEBUG == 1)
    qDebug() << QString(tr("Download %1 Succeed.\n file bytes: %2\n file path:%3")
                        .arg(fileInfo.fileName())
                        .arg(fileInfo.size())
                        .arg(QDir::toNativeSeparators(fileInfo.absolutePath())));
#endif
    emit download_succeed();
}

void downloadTool::on_http_readyRead()
{
    if (file) {
        file->write(reply->readAll());
    }
}

void downloadTool::on_http_error(QNetworkReply::NetworkError error)
{
#if (DOWNLOAD_DEBUG == 1)
    qDebug() << QString("errorCode:%1 \n %2")
                .arg(error)
                .arg(reply->errorString());
#endif
    emit download_error(error);
}

void downloadTool::networkReplyProgress(qint64 bytesRead, qint64 totalBytes)
{
    qreal progress = qreal(bytesRead * 100) / qreal(totalBytes); // 进度

    QString progressInfo;
    if(totalBytes == -1) { // 表明下载的文件大小未知
        on_http_error(QNetworkReply::UnknownServerError);
        return;
    }
    if(totalBytes < 1024) { // 代表文件小于1KB
        progressInfo = QString("%1 Bytes / %2 Bytes").arg(bytesRead).arg(totalBytes);
    } else if(totalBytes < 1024*1024) { // 代表文件小于1MB
        progressInfo = QString("%1 Kb / %2 Kb")
                                .arg(QString::number(qreal(bytesRead/1024.f), 'f', 3))
                                .arg(QString::number(qreal(totalBytes/1024.f), 'f', 3));
    } else {
        progressInfo = QString("%1 Mb / %2 Mb")
                                .arg(QString::number(qreal(bytesRead/1024.f/1024.f), 'f', 3))
                                .arg(QString::number(qreal(totalBytes/1024.f/1024.f), 'f', 3));
    }
#if (DOWNLOAD_DEBUG == 1)
    qDebug() << QString("下载进度: %1%").arg(QString::number(progress, 'f', 1)) <<progressInfo;
#endif
    emit sigProgress(bytesRead, totalBytes, progress, progressInfo);
}

std::unique_ptr<QFile> downloadTool::openFileForWrite(const QString& fileName)
{
    std::unique_ptr<QFile> file(new QFile(fileName));
    if (!file->open(QIODevice::WriteOnly)) {
#if (DOWNLOAD_DEBUG == 1)
        qDebug() << QString("Unable to save the file %1: %2.")
            .arg(QDir::toNativeSeparators(fileName), file->errorString());
#endif
        return nullptr;
    }
    return file;
}
