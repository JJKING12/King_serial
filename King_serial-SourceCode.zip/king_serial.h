#ifndef KING_SERIAL_H
#define KING_SERIAL_H

#include <QMainWindow>
/* 串口类 */
#include <QtSerialPort>
#include <QSerialPortInfo>
/* 网络编程类 */
#include <QTcpSocket>
#include <QUdpSocket>
/* ModBus类 */
#include <QModbusDataUnit>
#include <QModbusRtuSerialMaster>
#include <QModbusTcpClient>

#include <QTimer>
#include <QMessageBox>
#include <QProgressDialog>
#include <QDebug>
#include <QtWin>
#include <QMouseEvent>
#include <QPoint>
#include <QDesktopWidget>

#include "plotsetting.h"

#include "api/api.h"
#include "appconfig/appconfig.h"
#include "qtcpsocket.h"
#include "tcp/tcpserver.h"
#include "qcustomplot/qcustomplot.h"
#include "helper/framelesshelper.h"
#include "DownloadTool/downloadtool.h"

// 压缩与解压缩支持
#include "QtGui/private/qzipreader_p.h"
#include "QtGui/private/qzipwriter_p.h"

// 博客地址
#define     MYBLOG_LINK     "<a href=https://blog.csdn.net/JJ_KING123>"

// 邮箱地址
#define     MAILBOX_LINK    "<a href=http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=2Onr7ujp4OHu6_uYqan2u7e1><img src=http://rescdn.qqmail.com/zh_CN/htmledition/images/function/qm_open/ico_mailme_11.png/>"

// 更新地址
#define     UPDATE_URL      "https://gitee.com/wjjxln/tools/raw/master/update.json"

// ModBus表格行数
#define     TABEL_RAW    8 // 最大8行

/* 定义浮点数与uint32_t int32_t的共用体 */
typedef union  {
    float F;
    quint8 buf[4]; // 这里需要注意 Qt默认为小端存储
} union_FloatConvert_typedef;

/* 定义double类型与uint64_t int64_t的共用体 */
typedef union  {
    double D;
    quint8 buf[8]; // 这里需要注意 Qt默认为小端存储
} union_DoubleConvert_typedef;

/* 主题类型 */
typedef enum {
    theme_flatWhite,
    theme_lightBlue,
    theme_lightPurple,
    theme_ElegantDark,
    theme_Manjaro,
    theme_Console,
    theme_MacOS,
} enum_theme_typedef;

/* 消息类型 */
typedef enum {
    msgType_serial_send, // 0 串口发送
    msgType_serial_recv, // 1 串口接收
    msgType_network_send,// 2 网络发送
    msgType_network_recv,// 3 网络接收
    msgType_modbus_send, // 4 ModBus发送
    msgType_modbus_recv, // 5 ModBus接收
    msgType_about,       // 6 提示
    msgType_error,       // 7 错误
} enum_msgType_typedef;

/* 网络模式 */
typedef enum {
    NetMode_TcpServer,
    NetMode_TcpSocket,
    NetMode_UdpServer,
    NetMode_UdpSocket,
} enum_NetMode_typedef;

/* ModBus模式 */
typedef enum {
    ModBus_ASCII,
    ModBus_RTU,
    ModBus_TCP,
} enum_ModBusType_typedef;

/* ModBus数据格式 */
typedef enum {
    ModBus_Format_Signed,
    ModBus_Format_Unsigned,
    ModBus_Format_Hex,
    ModBus_Format_Binary,
    ModBus_Format_32BitSigned,
    ModBus_Format_32BitUnsigned,
    ModBus_Format_Float,
    ModBus_Format_64BitSigned,
    ModBus_Format_64BitUnsigned,
    ModBus_Format_Double,
}  enum_ModBusDataFormat_typedef;

/* ModBus字节序 */
typedef enum {
    ModBusEndian_Big,       // 大端字节序 A B C D
    ModBusEndian_Little,    // 小端字节序 D C B A
    ModBusEndian_BigSwap,   // 大端字节序交换 B A D C
    ModBusEndian_LittleSwap,// 小端字节序交换 C D A B
} enum_MOdBusEndian_typedef;

/* 串口结构体 */
typedef struct {
    QString portName;
    qint32 baudrate;
    int dataBit;
    int parityBit;
    int stopBit;
    int flowControl;
    QStringList old_serialportinfo;
    QStringList new_serialportinfo;
    unsigned long sleepTime;

    bool isOpen;
    bool isShow;
    bool isScroll;
    bool istimeStamp;
    qint64 sendCount;
    qint64 recvCount;
} struct_Serial_typedef;

/* 波形结构体 */
typedef struct {
    bool isOpen;            // 是否开启绘图
    bool autoRefresh_Y;     // 是否开启自动刷新坐标轴
    bool isEnlarge;         // 是否放大波形
    int plotNum;            // 波形个数
    int x_point_cnt;        // 当前针对x轴的点计数
    double x_minValue;      // x轴数据最小值
    double x_maxValue;      // x轴数据最大值
    double y_minValue;      // y轴数据最小值
    double y_maxValue;      // y轴数据最大值
    QColor line_colors[12]; // 波形曲线颜色
} struct_customPlot_typedef;

/* 网络结构体 */
typedef struct {
    int mode;
    QString ip;
    quint16 port;
    QString udpIP;
    quint16 udpPort;
    bool isOpen;
} struct_network_typedef;

/* ModBus结构体 */
typedef struct {
    bool isOpen;            // 是否开启ModBus协议传输
    QString slaveAddr;      // 从机地址
    QString FuncCode;       // 功能码
    QString DataAddr;       // 数据读取地址
    quint16 DataLen;        // 数据读取长度
    quint16 CRC16;          // CRC16校验

    QString Transaction_ID; // 事务处理标识
    QString Protocol_ID;    // 协议标识
    QString NextLen;        // 报头之后的长度
} struct_ModBus_typedef;

namespace Ui {
class King_serial;
}

// 设置tableview某行/列不可编辑 class类
class ReadOnlyDelegate: public QItemDelegate
{
    public:
        ReadOnlyDelegate(QWidget *parent = nullptr):QItemDelegate(parent){}
        QWidget *createEditor(QWidget *parent, const QStyleOptionViewItem &option,const QModelIndex &index) const override;
};

class King_serial : public QMainWindow
{
    Q_OBJECT

public:
    explicit King_serial(QWidget *parent = nullptr);
    ~King_serial();

    void sleep(unsigned long msec);

private slots:
    /* ------------------------------------------------- 标题栏部分 ----------------------------------------------- */
    /* ------------------------------------------------- 标题栏部分 ----------------------------------------------- */
    /* ------------------------------------------------- 标题栏部分 ----------------------------------------------- */
    void initTitleBar();
    void on_pushButton_min_clicked();
    void on_pushButton_max_clicked();
    void on_pushButton_close_clicked();
    void mousePressEvent(QMouseEvent *event);   // 鼠标点击
    void mouseReleaseEvent(QMouseEvent *event); // 鼠标释放
    void resizeEvent(QResizeEvent* event);
    void setButtonImage(QPushButton *button, QString image, int w, int h);
    /* ------------------------------------------------- 状态栏部分 ----------------------------------------------- */
    /* ------------------------------------------------- 状态栏部分 ----------------------------------------------- */
    /* ------------------------------------------------- 状态栏部分 ----------------------------------------------- */
    void InitStatusBar();
    void styleChanged();
    /* ------------------------------------------------- 通用部分 ----------------------------------------------- */
    /* ------------------------------------------------- 通用部分 ----------------------------------------------- */
    /* ------------------------------------------------- 通用部分 ----------------------------------------------- */
    // 参数初始化配置
    void king_serial_init();
    // 基础配置
    void basic_config();
    // 数据发送
    void sendData();
    // 不同消息类型显示
    void sendInfo(int type, const QString &data, bool clear);
    // 自动发送勾选框事件
    void on_checkBox_auto_send_stateChanged(int arg1);
    // 设置自动保存
    void on_checkBox_auto_save_stateChanged(int arg1);
    // 暂停显示
    void on_pushButton_pauseShow_clicked();
    // 自动滚屏
    void on_pushButton_auto_scroll_clicked();
    // 清除接收显示
    void on_pushButton_clear_recv_clicked();
    // 窗口置顶
    void on_checkBox_topShow_stateChanged(int arg1);
    // 多条发送0
    void on_pushButton_send0_clicked();
    // 多条发送1
    void on_pushButton_send1_clicked();
    // 多条发送2
    void on_pushButton_send2_clicked();
    // 多条发送3
    void on_pushButton_send3_clicked();
    // 多条发送4
    void on_pushButton_send4_clicked();
    // 多条发送5
    void on_pushButton_send5_clicked();
    // 多条发送6
    void on_pushButton_send6_clicked();
    // 多条发送7
    void on_pushButton_send7_clicked();
    // 多条发送8
    void on_pushButton_send8_clicked();
    // 多条发送9
    void on_pushButton_send9_clicked();
    // 获取安装位置
    QString appPath();
    void on_tabWidget_currentChanged(int index);

    void on_pushButton_check_update_clicked();

    void Json_showProgress(qint64 bytesRead, qint64 totalBytes, qreal progress, QString progressInfo);
    void Json_downloadFailed();
    void Json_downloadSucceed();

    bool ParseJson(QString filePath, QString fileName);

    void Soft_showProgress(qint64 bytesRead, qint64 totalBytes, qreal progress, QString progressInfo);
    void Soft_downloadFailed();
    void Soft_downloadSucceed();
    /* ------------------------------------------------- 串口部分 ----------------------------------------------- */
    /* ------------------------------------------------- 串口部分 ----------------------------------------------- */
    /* ------------------------------------------------- 串口部分 ----------------------------------------------- */
    // 串口配置
    void serial_config();
    // 串口数据发送
    void sendBuff(QString data);
    // 串口数据接收
    void serial_recvData();
    // 串口数据保存
    void serial_saveData();
    // 打开串口按钮点击事件
    void on_pushButton_serial_openOrclose_clicked();
    // 事件过滤器 用于按下Enter发送
    bool eventFilter(QObject *target, QEvent *event);
    // 获取串口号
    QStringList serial_getPortNameList();
    // 定时刷新串口
    void timer_basic_task();
    // 串口发送字节统计
    void on_pushButton_sendCount_clicked();
    // 串口接收字节统计
    void on_pushButton_recvCount_clicked();
    // 串口ui控件使能配置
    void serial_ui_control_setEnanble(bool state);
    void on_comboBox_serial_portName_currentIndexChanged(const QString &arg1);
    // 保存的配置
    void saveConfig();

    /* ------------------------------------------------- 网络部分 ----------------------------------------------- */
    /* ------------------------------------------------- 网络部分 ----------------------------------------------- */
    /* ------------------------------------------------- 网络部分 ----------------------------------------------- */
    bool isIpAddr(QString ip);
    // 启动网络服务按钮点击事件
    void on_pushButton_network_start_clicked();
    // 网络模式改变事件
    void on_comboBox_network_mode_currentIndexChanged(int index);
    // 移除客户端按钮点击事件
    void on_pushButton_network_remove_clicked();
    // 网络配置
    void network_config();
    // 网络ui控件使能配置
    void network_ui_control_setEnanble(bool state);
    // 获取本地IP地址
    QString network_getLocalIp();
    // 网络ui控件显示使能
    void network_ui_server_isShow(bool show);
    // tcp服务端链接
    void tcpServer_connected(const QString &ip, int port);
    // tcp服务端断开链接
    void tcpServer_disconnected(const QString &ip, int port);
    // tcp服务端错误
    void tcpServer_error(const QString &ip, int port, const QString &error);
    // tcp服务端发送消息
    void tcpServer_sendData(const QString &ip, int port, const QString &data);
    // tcp服务端接收消息
    void tcpServer_recvData(const QString &ip, int port, const QString &data);
    // tcp客户端链接
    void tcpSocket_connected();
    // tcp客户端断开链接
    void tcpSocket_disconnected();
    // tcp客户端接收数据
    void tcpSocket_recvData();
    // tcp客户端错误
    void tcpSocket_error();
    // udp服务端接收数据
    void udpServer_recvData();
    // udp服务端错误
    void udpServer_error();
    // udp客户端接受消息
    void udpSocket_recvData();
    // udp客户端错误
    void udpSocket_error();
    void on_comboBox_network_ip_currentIndexChanged(const QString &arg1);

    /* ------------------------------------------------- 波形部分 ----------------------------------------------- */
    /* ------------------------------------------------- 波形部分 ----------------------------------------------- */
    /* ------------------------------------------------- 波形部分 ----------------------------------------------- */
    void plot_config();
    void wheelEvent(QWheelEvent *event);
    void mouseMoveEvent(QMouseEvent *e);
    void on_pushButton_plot_start_clicked();

    void on_pushButton_plot_setting_clicked();

    void analysis_Data(struct_param_typedef data, bool isOk);

    void selectionChanged();

    void plot_updateData(QByteArray data);

    void legend_double_click(QCPLegend *legend, QCPAbstractLegendItem *item, QMouseEvent *event);

    void on_pushButton_plot_refresh_clicked();

    void on_pushButton_plot_save_clicked();

    void on_pushButton_plot_autoOrHand_clicked();

    void on_pushButton_plot_hideOrShow_clicked();

    void on_pushButton_plot_resize_clicked();
    /* ------------------------------------------------- ModBus部分 ----------------------------------------------- */
    /* ------------------------------------------------- ModBus部分 ----------------------------------------------- */
    /* ------------------------------------------------- ModBus部分 ----------------------------------------------- */
    void ModBus_config();

    void on_pushButton_modBus_open_clicked();

    void on_pushButton_modBus_send_clicked();

    void on_lineEdit_modBus_readAddr_textChanged(const QString &arg1);

    void ModBus_ui_control_setEnanble(bool state);

    void modBus_analysisData(QString data);

    void modBus_serialMode_analysisData(QStringList datList);

    void on_comboBox_modBus_mode_currentIndexChanged(int index);

private:
    Ui::King_serial *ui;
    QLabel *label_style;        // 状态栏 标签
    QComboBox *cBox_style;      // 状态栏 下拉框

    QSerialPort *serialPort;    // 串口类
    QTcpSocket *tcpSocket;      // tcp 客户端
    TcpServer *tcpServer;       // tcp 服务端
    QUdpSocket *udpServer;      // udp 服务端
    QUdpSocket *udpSocket;      // udp 客户端
    QModbusRtuSerialMaster *RtuModBus;  // ModBus rtu格式
    QModbusTcpClient *TcpModBus;        // ModBus tcp格式

    QCustomPlot *customPlot;    // 波形类
    plotSetting *plotSet;       // 波形设置 窗口

    QTimer *timer_basic;        // 通用任务定时器 基础定时器
    QTimer *timer_send;         // 数据发送定时器
    QTimer *timer_serial_recv;  // 数据接收定时器
    QTimer *timer_save;         // 数据保存定时器

    QString IconUrl;            // 软件图标文件地址
    QColor PlotUIColor;         // 波形UI的颜色
    QPoint m_point;             // 添加类成员m_point（QPoint类型）
    QString softVersion;        // 软件版本
    QString downloadUrl;        // 软件下载地址

    struct_Serial_typedef mySerial;     // 结构体 串口
    struct_network_typedef myNetwork;   // 结构体 网络
    struct_customPlot_typedef myPlot;   // 结构体 波形
    struct_param_typedef param;         // 结构体 波形设置参数
    struct_ModBus_typedef myModBus;     // 结构体 ModBus

    QString updateFileName;                 // 更新的软件的文件名
    QProgressDialog *Json_progressDialog;   // Json文件 进度条指示
    QProgressDialog *Soft_progressDialog;   // 下载软件 进度条指示
    downloadTool *json_down;                // json文件 下载类
    downloadTool *soft_down;                // soft软件 下载类

    FramelessHelper *mHelper;       // 定义无边框窗体类
};

#endif // KING_SERIAL_H
