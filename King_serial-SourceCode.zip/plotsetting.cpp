#include "plotsetting.h"
#include "ui_plotsetting.h"

plotSetting::plotSetting(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::plotSetting)
{
    ui->setupUi(this);
    this->resize(240, 120);
    this->setWindowTitle("协议配置");

    // 限制 帧头和帧尾 只能输入Hex数据
    QRegExp regExp("^[0-9a-fA-F ]+$"); // 正则表达式过滤
    ui->lineEdit_frame_head->setValidator( new QRegExpValidator(regExp));
    ui->lineEdit_frame_tail->setValidator( new QRegExpValidator(regExp));

    // 1.重写控件内容
    on_lineEdit_frame_head_textEdited(AppConfig::PlotHead);
    on_lineEdit_frame_tail_textEdited(AppConfig::PlotTail);
    ui->lineEdit_channel_name_split->setText(AppConfig::PlotChannelNameSplit);
    ui->lineEdit_channel_data_split->setText(AppConfig::PlotChannelDataSplit);
    // 2.连接需要绑定的控件信号与槽 绑定ini文件
    connect(ui->lineEdit_frame_head, SIGNAL(textChanged(QString)), this, SLOT(PlotConfig()));
    connect(ui->lineEdit_frame_tail, SIGNAL(textChanged(QString)), this, SLOT(PlotConfig()));
    connect(ui->lineEdit_channel_name_split, SIGNAL(textChanged(QString)), this, SLOT(PlotConfig()));
    connect(ui->lineEdit_channel_data_split, SIGNAL(textChanged(QString)), this, SLOT(PlotConfig()));
}

plotSetting::~plotSetting()
{
    delete ui;
}

void plotSetting::closeEvent(QCloseEvent *e)
{
    e->accept();
    emit get_paramData(plotDat, false);
}

void plotSetting::PlotConfig()
{
    AppConfig::PlotHead = ui->lineEdit_frame_head->text();
    AppConfig::PlotTail = ui->lineEdit_frame_tail->text();
    AppConfig::PlotChannelNameSplit = ui->lineEdit_channel_name_split->text();
    AppConfig::PlotChannelDataSplit = ui->lineEdit_channel_data_split->text();
    AppConfig::writeConfig();
}

void plotSetting::on_pushButton_confirm_clicked()
{
    plotDat.head = ui->lineEdit_frame_head->text();
    plotDat.tail = ui->lineEdit_frame_tail->text();
    plotDat.channel_name_split = ui->lineEdit_channel_name_split->text();
    plotDat.channel_data_split = ui->lineEdit_channel_data_split->text();
    if(ui->lineEdit_frame_head->text().count()<4 || ui->lineEdit_frame_tail->text()<4) {
        QMessageBox::critical(this, "Tips", "数据帧头或帧尾格式错误，请重新配置...");
        return;
    }
    emit get_paramData(plotDat, true);
    this->close();
}

void plotSetting::on_pushButton_cancel_clicked()
{
    emit get_paramData(plotDat, false);
    this->close();
}

void plotSetting::on_lineEdit_frame_head_textEdited(const QString &arg1)
{
    QString uStr = arg1;
    uStr.remove(" "); // 移除空格

    if (uStr.length() > 3 && uStr.length() % 2 == 0) {
       QString uStr2, uStr3;
       for (int i = 0; i < (uStr.length() / 2 - 1); i++) {
           uStr2 = uStr.mid(i * 2, 2);  // 取子串
           uStr3 += uStr2 + " ";        // 加空格
       }
       uStr2 = uStr.mid(uStr.length() - 2, 2); // 加上后面的
       uStr3 += uStr2;

       ui->lineEdit_frame_head->setText(uStr3);
    }
}

void plotSetting::on_lineEdit_frame_tail_textEdited(const QString &arg1)
{
    QString uStr = arg1;
    uStr.remove(" "); // 移除空格

    if (uStr.length() > 3 && uStr.length() % 2 == 0) {
       QString uStr2, uStr3;
       for (int i = 0; i < (uStr.length() / 2 - 1); i++) {
           uStr2 = uStr.mid(i * 2, 2);  // 取子串
           uStr3 += uStr2 + " ";        // 加空格
       }
       uStr2 = uStr.mid(uStr.length() - 2, 2); // 加上后面的
       uStr3 += uStr2;

       ui->lineEdit_frame_tail->setText(uStr3);
    }
}
