#include "appconfig.h"

QString AppConfig::ConfigFile = "config.ini";
QString AppConfig::softVersion = QString::fromUtf8("V1.2.0");
QString AppConfig::downloadUrl = QString::fromUtf8("https://developer-oss.lanzouc.com/file/?UDZXaQk4UmNSWwQ8AzYBbVBvATlUQAphVj8EZV1eVAECbVVtCTgCeFF9CjVRdVx7VWkDb1NgUDcKUgBvXWUDP1BhVzUJZVI/UjMEYQNkATVQPQEiVG0Ke1ZsBDBdMFRhAjpVMQlhAmVRPwp6UXVcLVUyAzRTPFBgCj4AKV0wAzBQf1cxCWRSKVIwBDYDZwEzUDsBNlQ6Cj5WZARgXTdUYgI2VTsJMAJnUWMKaFExXGhVbQM0Uz9QNApoAGBdMgNnUGhXMgljUjRSKgQoAz4BcFAsAXFUeAptViMEa11lVGgCMVU2CWUCblE1CmpRPVx7VXsDb1NhUDcKawA7XTADNVBgVzIJZlI/Uj0EawNkAThQJAEqVC0KblY9BHVdPFRkAjVVMglmAmRRPgpkUT1cZVU5AyBTeVAiCnoAO10wAzVQYFcyCWZSN1I2BGYDZQExUCwBcVRiCnhWbAQxXTdUewIzVTMJZwJ4UTYKbVE8XHNVOQMx");
bool AppConfig::flag_firstUse = true;
int AppConfig::width = 400;
int AppConfig::height = 300;

/* ------------------ 基本参数 ------------------ */
bool AppConfig::HexSend = false;
bool AppConfig::HexReceive = false;
bool AppConfig::TimeStamp = true;
bool AppConfig::AutoClear = false;
bool AppConfig::Auto_Return = true;
bool AppConfig::TopShow = false;

bool AppConfig::AutoSend = false;
bool AppConfig::AutoSave = false;
int AppConfig::SendInterval = 1000;
int AppConfig::SaveInterval = 5000;
QString AppConfig::Theme = QString::fromUtf8("White");

/* ------------------ 串口参数 ------------------ */
int AppConfig::BaudRate = 115200;
int AppConfig::DataBit = 8;
QString AppConfig::Parity = QString::fromUtf8("无");
double AppConfig::StopBit = 1;
QString AppConfig::FlowControl = QString::fromUtf8("无");
QString AppConfig::TextSend = QString::fromUtf8("Welcome to King_Tool!");

/* ------------------ 网络参数 ------------------ */
QString AppConfig::NetMode = QString::fromUtf8("TCP Server");
QString AppConfig::NetIP = QString::fromUtf8("127.0.0.1");
int AppConfig::NetPort = 8888;
QString AppConfig::NetUDPIP = QString::fromUtf8("127.0.0.1");
int AppConfig::NetUDPPort = 6000;
bool AppConfig::NetReConnect = false;
bool AppConfig::NetSendAll = true;

/* ------------------ 波形参数 ------------------ */
QString AppConfig::PlotHead = QString::fromUtf8("A5 A5");
QString AppConfig::PlotTail = QString::fromUtf8("5A 5A");
QString AppConfig::PlotChannelNameSplit = QString::fromUtf8(",");
QString AppConfig::PlotChannelDataSplit = QString::fromUtf8(" ");
int AppConfig::PlotObserveNum = 100;

/* ----------------- 多条发送参数 ----------------- */
bool AppConfig::CheckSend0 = false;
bool AppConfig::CheckSend1 = false;
bool AppConfig::CheckSend2 = false;
bool AppConfig::CheckSend3 = false;
bool AppConfig::CheckSend4 = false;
bool AppConfig::CheckSend5 = false;
bool AppConfig::CheckSend6 = false;
bool AppConfig::CheckSend7 = false;
bool AppConfig::CheckSend8 = false;
bool AppConfig::CheckSend9 = false;
QString AppConfig::TextSend0 = QString::fromUtf8("");
QString AppConfig::TextSend1 = QString::fromUtf8("");
QString AppConfig::TextSend2 = QString::fromUtf8("");
QString AppConfig::TextSend3 = QString::fromUtf8("");
QString AppConfig::TextSend4 = QString::fromUtf8("");
QString AppConfig::TextSend5 = QString::fromUtf8("");
QString AppConfig::TextSend6 = QString::fromUtf8("");
QString AppConfig::TextSend7 = QString::fromUtf8("");
QString AppConfig::TextSend8 = QString::fromUtf8("");
QString AppConfig::TextSend9 = QString::fromUtf8("");

/* ------------------ ModBus参数 ------------------ */
QString AppConfig::ModBusProtocol = QString::fromUtf8("ASCII");     // 协议类型
QString AppConfig::ModBusReadFormat = QString::fromUtf8("Signed");  // 读取格式
QString AppConfig::ModBusByteEndian = QString::fromUtf8("Big-endian");  // 数据大小端
QString AppConfig::ModBusSlaveAddr = QString::fromUtf8("01");       // 从机地址
QString AppConfig::ModBusFuncCode = QString::fromUtf8("03");        // 功能码
QString AppConfig::ModBusReadAddr = QString::fromUtf8("00 00");     // 读取地址（起始）
QString AppConfig::ModBusReadLen = QString::fromUtf8("2");          // 读取长度

bool AppConfig::checkIniFile(const QString &iniFile)
{
    //如果配置文件大小为0,则以初始值继续运行,并生成配置文件
    QFile file(iniFile);
    if (file.size() == 0) {
        return false;
    }
    //如果配置文件不完整,则以初始值继续运行,并生成配置文件
    if (file.open(QFile::ReadOnly)) {
        bool ok = true;
        while (!file.atEnd()) {
            QString line = file.readLine();
            line.replace("\r", "");
            line.replace("\n", "");
            QStringList list = line.split("=");
            if (list.count() == 2) {
                QString key = list.at(0);
                QString value = list.at(1);
                if (value.isEmpty()) {
                    qDebug() << CURR_TIME << "ini node no value" << key;
                    ok = false;
                    break;
                }
            }
        }
        if (!ok) {
            return false;
        }
    } else {
        return false;
    }
    return true;
}

void AppConfig::readConfig()
{
    QSettings set(AppConfig::ConfigFile, QSettings::IniFormat);

    set.beginGroup("SoftConfig");
    AppConfig::softVersion = set.value("softVersion", AppConfig::softVersion).toString();
    AppConfig::downloadUrl = set.value("downloadUrl", AppConfig::downloadUrl).toString();
    AppConfig::flag_firstUse = set.value("flag_firstUse", AppConfig::flag_firstUse).toBool();
    AppConfig::width = set.value("width", AppConfig::width).toInt();
    AppConfig::height = set.value("height", AppConfig::height).toInt();
    set.endGroup();

    set.beginGroup("BasicConfig");
    AppConfig::HexSend = set.value("HexSend", AppConfig::HexSend).toBool();
    AppConfig::HexReceive = set.value("HexReceive", AppConfig::HexReceive).toBool();
    AppConfig::TimeStamp = set.value("TimeStamp", AppConfig::TimeStamp).toBool();
    AppConfig::AutoClear = set.value("AutoClear", AppConfig::AutoClear).toBool();
    AppConfig::Auto_Return = set.value("Auto_Return", AppConfig::Auto_Return).toBool();
    AppConfig::TopShow = set.value("TopShow", AppConfig::TopShow).toBool();

    AppConfig::AutoSend = set.value("AutoSend", AppConfig::AutoSend).toBool();
    AppConfig::AutoSave = set.value("AutoSave", AppConfig::AutoSave).toBool();
    AppConfig::SendInterval = set.value("SendInterval", AppConfig::SendInterval).toInt();
    AppConfig::SaveInterval = set.value("SaveInterval", AppConfig::SaveInterval).toInt();
    AppConfig::Theme = set.value("Theme", AppConfig::Theme).toString();
    set.endGroup();

    set.beginGroup("ComConfig");
    AppConfig::BaudRate = set.value("BaudRate", AppConfig::BaudRate).toInt();
    AppConfig::DataBit = set.value("DataBit", AppConfig::DataBit).toInt();
    AppConfig::Parity = set.value("Parity", AppConfig::Parity).toString();
    AppConfig::StopBit = set.value("StopBit", AppConfig::StopBit).toInt();
    AppConfig::FlowControl = set.value("FlowControl", AppConfig::FlowControl).toString();
    AppConfig::TextSend = set.value("TextSend", AppConfig::TextSend).toString();
    set.endGroup();

    set.beginGroup("NetConfig");
    AppConfig::NetMode = set.value("NetMode", AppConfig::NetMode).toString();
    AppConfig::NetIP = set.value("NetIP", AppConfig::NetIP).toString();
    AppConfig::NetPort = set.value("NetPort", AppConfig::NetPort).toInt();
    AppConfig::NetUDPIP = set.value("NetUDPIP", AppConfig::NetUDPIP).toString();
    AppConfig::NetUDPPort = set.value("NetUDPPort", AppConfig::NetUDPPort).toInt();
    AppConfig::NetReConnect = set.value("NetReConnect", AppConfig::NetReConnect).toBool();
    AppConfig::NetSendAll = set.value("NetSendAll", AppConfig::NetSendAll).toBool();
    set.endGroup();

    set.beginGroup("PlotConfig");
    AppConfig::PlotHead = set.value("PlotHead", AppConfig::PlotHead).toString();
    AppConfig::PlotTail = set.value("PlotTail", AppConfig::PlotTail).toString();
    AppConfig::PlotChannelNameSplit = set.value("PlotChannelNameSplit", AppConfig::PlotChannelNameSplit).toString();
    AppConfig::PlotChannelDataSplit = set.value("PlotChannelDataSplit", AppConfig::PlotChannelDataSplit).toString();
    AppConfig::PlotObserveNum = set.value("PlotObserveNum", AppConfig::PlotObserveNum).toInt();
    set.endGroup();

    set.beginGroup("SendSomeConfig");
    AppConfig::CheckSend0 = set.value("CheckSend0", AppConfig::CheckSend0).toBool();
    AppConfig::CheckSend1 = set.value("CheckSend1", AppConfig::CheckSend1).toBool();
    AppConfig::CheckSend2 = set.value("CheckSend2", AppConfig::CheckSend2).toBool();
    AppConfig::CheckSend3 = set.value("CheckSend3", AppConfig::CheckSend3).toBool();
    AppConfig::CheckSend4 = set.value("CheckSend4", AppConfig::CheckSend4).toBool();
    AppConfig::CheckSend5 = set.value("CheckSend5", AppConfig::CheckSend5).toBool();
    AppConfig::CheckSend6 = set.value("CheckSend6", AppConfig::CheckSend6).toBool();
    AppConfig::CheckSend7 = set.value("CheckSend7", AppConfig::CheckSend7).toBool();
    AppConfig::CheckSend8 = set.value("CheckSend8", AppConfig::CheckSend8).toBool();
    AppConfig::CheckSend9 = set.value("CheckSend9", AppConfig::CheckSend9).toBool();
    AppConfig::TextSend0  = set.value("TextSend0", AppConfig::TextSend0).toString();
    AppConfig::TextSend1  = set.value("TextSend1", AppConfig::TextSend1).toString();
    AppConfig::TextSend2  = set.value("TextSend2", AppConfig::TextSend2).toString();
    AppConfig::TextSend3  = set.value("TextSend3", AppConfig::TextSend3).toString();
    AppConfig::TextSend4  = set.value("TextSend4", AppConfig::TextSend4).toString();
    AppConfig::TextSend5  = set.value("TextSend5", AppConfig::TextSend5).toString();
    AppConfig::TextSend6  = set.value("TextSend6", AppConfig::TextSend6).toString();
    AppConfig::TextSend7  = set.value("TextSend7", AppConfig::TextSend7).toString();
    AppConfig::TextSend8  = set.value("TextSend8", AppConfig::TextSend8).toString();
    AppConfig::TextSend9  = set.value("TextSend9", AppConfig::TextSend9).toString();
    set.endGroup();

    set.beginGroup("ModBusConfig");
    AppConfig::ModBusProtocol = set.value("ModBusProtocol", AppConfig::ModBusProtocol).toString();
    AppConfig::ModBusReadFormat = set.value("ModBusReadFormat", AppConfig::ModBusReadFormat).toString();
    AppConfig::ModBusByteEndian = set.value("ModBusByteEndian", AppConfig::ModBusByteEndian).toString();
    AppConfig::ModBusSlaveAddr = set.value("ModBusSlaveAddr", AppConfig::ModBusSlaveAddr).toString();
    AppConfig::ModBusFuncCode = set.value("ModBusFuncCode", AppConfig::ModBusFuncCode).toString();
    AppConfig::ModBusReadAddr = set.value("ModBusReadAddr", AppConfig::ModBusReadAddr).toString();
    AppConfig::ModBusReadLen = set.value("ModBusReadLen", AppConfig::ModBusReadLen).toString();
    set.endGroup();

    //配置文件不存在或者不全则重新生成
    if (!checkIniFile(AppConfig::ConfigFile)) {
        writeConfig();
        return;
    }
}

void AppConfig::writeConfig()
{
    QSettings set(AppConfig::ConfigFile, QSettings::IniFormat);

    set.beginGroup("SoftConfig");
    set.setValue("softVersion", AppConfig::softVersion);
    set.setValue("downloadUrl", AppConfig::downloadUrl);
    set.setValue("flag_firstUse", AppConfig::flag_firstUse);
    set.setValue("width", AppConfig::width);
    set.setValue("height", AppConfig::height);
    set.endGroup();

    set.beginGroup("BasicConfig");
    set.setValue("HexSend", AppConfig::HexSend);
    set.setValue("HexReceive", AppConfig::HexReceive);
    set.setValue("TimeStamp", AppConfig::TimeStamp);
    set.setValue("AutoClear", AppConfig::AutoClear);
    set.setValue("Auto_Return", AppConfig::Auto_Return);
    set.setValue("TopShow", AppConfig::TopShow);
    set.setValue("AutoSend", AppConfig::AutoSend);
    set.setValue("AutoSave", AppConfig::AutoSave);
    set.setValue("SendInterval", AppConfig::SendInterval);
    set.setValue("SaveInterval", AppConfig::SaveInterval);
    set.setValue("Theme", AppConfig::Theme);
    set.endGroup();

    set.beginGroup("ComConfig");
    set.setValue("BaudRate", AppConfig::BaudRate);
    set.setValue("DataBit", AppConfig::DataBit);
    set.setValue("Parity", AppConfig::Parity);
    set.setValue("StopBit", AppConfig::StopBit);
    set.setValue("FlowControl", AppConfig::FlowControl);
    set.setValue("TextSend", AppConfig::TextSend);
    set.endGroup();

    set.beginGroup("NetConfig");
    set.setValue("NetMode", AppConfig::NetMode);
    set.setValue("NetIP", AppConfig::NetIP);
    set.setValue("NetPort", AppConfig::NetPort);
    set.setValue("NetUDPIP", AppConfig::NetUDPIP);
    set.setValue("NetUDPPort", AppConfig::NetUDPPort);
    set.setValue("NetReConnect", AppConfig::NetReConnect);
    set.setValue("NetSendAll", AppConfig::NetSendAll);
    set.endGroup();

    set.beginGroup("PlotConfig");
    set.setValue("PlotHead", AppConfig::PlotHead);
    set.setValue("PlotTail", AppConfig::PlotTail);
    set.setValue("PlotChannelNameSplit", AppConfig::PlotChannelNameSplit);
    set.setValue("PlotChannelDataSplit", AppConfig::PlotChannelDataSplit);
    set.setValue("PlotObserveNum", AppConfig::PlotObserveNum);
    set.endGroup();

    set.beginGroup("SendSomeConfig");
    set.setValue("CheckSend0", AppConfig::CheckSend0);
    set.setValue("CheckSend1", AppConfig::CheckSend1);
    set.setValue("CheckSend2", AppConfig::CheckSend2);
    set.setValue("CheckSend3", AppConfig::CheckSend3);
    set.setValue("CheckSend4", AppConfig::CheckSend4);
    set.setValue("CheckSend5", AppConfig::CheckSend5);
    set.setValue("CheckSend6", AppConfig::CheckSend6);
    set.setValue("CheckSend7", AppConfig::CheckSend7);
    set.setValue("CheckSend8", AppConfig::CheckSend8);
    set.setValue("CheckSend9", AppConfig::CheckSend9);
    set.setValue("TextSend0", AppConfig::TextSend0);
    set.setValue("TextSend1", AppConfig::TextSend1);
    set.setValue("TextSend2", AppConfig::TextSend2);
    set.setValue("TextSend3", AppConfig::TextSend3);
    set.setValue("TextSend4", AppConfig::TextSend4);
    set.setValue("TextSend5", AppConfig::TextSend5);
    set.setValue("TextSend6", AppConfig::TextSend6);
    set.setValue("TextSend7", AppConfig::TextSend7);
    set.setValue("TextSend8", AppConfig::TextSend8);
    set.setValue("TextSend9", AppConfig::TextSend9);
    set.endGroup();

    set.beginGroup("ModBusConfig");
    set.setValue("ModBusProtocol", AppConfig::ModBusProtocol);
    set.setValue("ModBusReadFormat", AppConfig::ModBusReadFormat);
    set.setValue("ModBusByteEndian", AppConfig::ModBusByteEndian);
    set.setValue("ModBusSlaveAddr", AppConfig::ModBusSlaveAddr);
    set.setValue("ModBusFuncCode", AppConfig::ModBusFuncCode);
    set.setValue("ModBusReadAddr", AppConfig::ModBusReadAddr);
    set.setValue("ModBusReadLen", AppConfig::ModBusReadLen);
    set.endGroup();
}
