#ifndef APPCONFIG_H
#define APPCONFIG_H

#include <QtCore>
#include <QtGui>
#include <QtNetwork>

#if (QT_VERSION >= QT_VERSION_CHECK(5,0,0))
#include <QtWidgets>
#endif

#if (QT_VERSION >= QT_VERSION_CHECK(6,0,0))
#include <QtCore5Compat>
#endif

#define CURR_TIME  qPrintable(QDateTime::currentDateTime().toString("yyyy/MM/dd HH:mm:ss.zzz"))

class AppConfig
{
public:
    static QString ConfigFile;          // 配置文件路径
    static QString softVersion;         // 软件版本
    static QString downloadUrl;         // 下载地址
    static bool flag_firstUse;          // 第一次使用
    static int width;                   // 软件宽度
    static int height;                  // 软件高度

    /* ------------------ 基本参数 ------------------ */
    static bool HexSend;                // 16进制发送
    static bool HexReceive;             // 16进制接收
    static bool TimeStamp;              // 时间戳
    static bool AutoClear;              // 自动清空
    static bool Auto_Return;            // 自动换行
    static bool TopShow;                // 置顶显示

    static bool AutoSend;               // 自动发送
    static bool AutoSave;               // 自动保存
    static int SendInterval;            // 自动发送间隔
    static int SaveInterval;            // 自动保存间隔
    static QString Theme;               // 主题索引

    /* ------------------ 串口参数 ------------------ */
    static int BaudRate;                // 波特率
    static int DataBit;                 // 数据位
    static QString Parity;              // 校验位
    static double StopBit;              // 停止位
    static QString FlowControl;         // 流控制
    static QString TextSend;            // 单条发送字符串

    /* ------------------ 网络参数 ------------------ */
    static QString NetMode;             // 转换模式
    static QString NetIP;               // 网络IP地址
    static int NetPort;                 // 网络端口
    static QString NetUDPIP;            // UDP远程网络IP地址
    static int NetUDPPort;              // UDP远程网络端口
    static bool NetReConnect;           // 自动重连
    static bool NetSendAll;             // 向所有客户端发送数据

    /* ------------------ 波形参数 ------------------ */
    static QString PlotHead;            // 波形帧头
    static QString PlotTail;            // 波形帧尾
    static QString PlotChannelNameSplit;// 波形通道名称分隔符
    static QString PlotChannelDataSplit;// 波形数据分隔符
    static int PlotObserveNum;          // 波形观测点数

    /* ----------------- 多条发送参数 ----------------- */
    static bool CheckSend0;
    static bool CheckSend1;
    static bool CheckSend2;
    static bool CheckSend3;
    static bool CheckSend4;
    static bool CheckSend5;
    static bool CheckSend6;
    static bool CheckSend7;
    static bool CheckSend8;
    static bool CheckSend9;
    static QString TextSend0;
    static QString TextSend1;
    static QString TextSend2;
    static QString TextSend3;
    static QString TextSend4;
    static QString TextSend5;
    static QString TextSend6;
    static QString TextSend7;
    static QString TextSend8;
    static QString TextSend9;

    /* ------------------ ModBus参数 ------------------ */
    static QString ModBusProtocol;      // 协议类型
    static QString ModBusReadFormat;    // 读取格式
    static QString ModBusByteEndian;    // 数据大小端
    static QString ModBusSlaveAddr;     // 从机地址
    static QString ModBusFuncCode;      // 功能码
    static QString ModBusReadAddr;      // 读取地址（起始）
    static QString ModBusReadLen;       // 读取长度

    /* ------------------ 参数读写配置 ------------------ */
    static void readConfig();           //读取配置参数
    static void writeConfig();          //写入配置参数
    static bool checkIniFile(const QString &iniFile);
};

#endif // APPCONFIG_H
